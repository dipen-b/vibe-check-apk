// Sippy — in-page reminder card. Renders a bottom-right slide-in overlay with
// the animated transparent "water buddy" (animated WebP) plus Drink / Snooze
// actions. Fully isolated inside a Shadow DOM so no host-page CSS can touch it.

(() => {
  if (window.__sippyLoaded) return;
  window.__sippyLoaded = true;

  const HOST_ID = "sippy-reminder-host";
  let autoHideTimer = null;

  // ---- audio -----------------------------------------------------------------
  // Chrome's autoplay policy forbids starting an AudioContext before the user
  // has interacted with the page — doing so logs a console warning. So we only
  // CREATE the context once a real user gesture happens, and only chime when
  // it's actually running. Before any interaction the reminder is simply silent
  // (the browser wouldn't let it make sound anyway).
  let sharedCtx = null;

  function unlockAudio() {
    if (sharedCtx) {
      if (sharedCtx.state === "suspended") sharedCtx.resume().catch(() => {});
      return;
    }
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    try {
      sharedCtx = new Ctx(); // created inside a gesture → allowed to run
      if (sharedCtx.state === "suspended") sharedCtx.resume().catch(() => {});
    } catch (e) {
      sharedCtx = null;
    }
  }
  ["pointerdown", "keydown", "touchstart"].forEach((ev) =>
    window.addEventListener(ev, unlockAudio, { capture: true, passive: true })
  );

  function playChime() {
    // no gesture yet / audio not unlocked → stay silent, no warning
    if (!sharedCtx || sharedCtx.state !== "running") return;
    try {
      const ctx = sharedCtx;
      const now = ctx.currentTime;
      // gentle two-note "water drop" chime
      [
        [880, 0.0],
        [1174.7, 0.13]
      ].forEach(([freq, t]) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.0001, now + t);
        gain.gain.exponentialRampToValueAtTime(0.15, now + t + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + t + 0.35);
        osc.connect(gain).connect(ctx.destination);
        osc.start(now + t);
        osc.stop(now + t + 0.4);
      });
    } catch (e) {
      /* ignore */
    }
  }

  function removeCard() {
    const host = document.getElementById(HOST_ID);
    if (!host) return;
    const wrap = host.shadowRoot && host.shadowRoot.querySelector(".wrap");
    if (wrap) {
      wrap.classList.remove("in");
      wrap.classList.add("out");
      setTimeout(() => host.remove(), 380);
    } else {
      host.remove();
    }
    if (autoHideTimer) clearTimeout(autoHideTimer);
  }

  function showCard({ count = 0, goal = 8, snoozeMinutes = 10, sound = true }) {
    // replace any existing card
    const prev = document.getElementById(HOST_ID);
    if (prev) prev.remove();
    if (autoHideTimer) clearTimeout(autoHideTimer);

    const buddyUrl = chrome.runtime.getURL("assets/reminder.webm");

    const host = document.createElement("div");
    host.id = HOST_ID;
    // keep the host itself out of the page flow / above everything
    host.style.cssText =
      "all:initial;position:fixed;right:0;bottom:0;width:0;height:0;z-index:2147483647;";
    const root = host.attachShadow({ mode: "open" });

    root.innerHTML = `
      <style>
        :host { all: initial; }
        * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont,
            "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }

        /* no card / no background — just the girl + buttons floating */
        .wrap {
          position: fixed;
          right: 20px;
          bottom: 20px;
          width: 232px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 12px;
          transform: translateX(150%);
          opacity: 0;
          transition: transform .5s cubic-bezier(.18,.9,.28,1.2), opacity .4s ease;
        }
        .wrap.in { transform: translateX(0); opacity: 1; }
        .wrap.out { transform: translateX(150%); opacity: 0; }

        .stage {
          position: relative;
          width: 100%;
          height: 300px;
        }
        /* portrait clip: full figure, centered, transparent (no background) */
        .stage .buddy {
          position: absolute;
          left: 50%; top: 50%;
          height: 100%; width: auto; display: block;
          transform: translate(-50%, -50%) scale(1.02);
          /* rim outlines so she reads on ANY background:
             thin dark edge (pops on white/light) + soft light halo (pops on
             dark) + a grounding shadow underneath */
          filter:
            drop-shadow(0 0 1px rgba(15,45,80,.65))
            drop-shadow(0 0 2px rgba(15,45,80,.45))
            drop-shadow(0 0 5px rgba(255,255,255,.5))
            drop-shadow(0 9px 12px rgba(20,60,110,.32));
          transition: transform .7s cubic-bezier(.42,0,.55,1), opacity .6s ease;
        }
        /* on Done/Snooze she walks off: middle -> out to the right */
        .stage .buddy.bye {
          transform: translate(210%, -50%) scale(1.02);
          opacity: 0;
        }

        .btns { display: flex; gap: 10px; width: 100%; }
        button.act {
          flex: 1; border: none; cursor: pointer; border-radius: 14px;
          padding: 12px 8px; font-size: 14px; font-weight: 750; white-space: nowrap;
          transition: transform .12s ease, filter .15s ease, background .15s ease;
        }
        button.act:active { transform: translateY(1px) scale(.99); }
        .done { color: #fff;
                background: linear-gradient(180deg,#46a3f2,#2277d8);
                box-shadow: 0 8px 22px rgba(20,60,110,.38); }
        .done:hover { filter: brightness(1.06); }
        .snooze { color: #24506f; background: #ffffff;
                  box-shadow: 0 8px 22px rgba(20,60,110,.28); }
        .snooze:hover { background: #eef5fc; }

        /* ---- tada / celebration burst ---- */
        .tada { position:absolute; inset:0; pointer-events:none; overflow:visible; z-index:6; }
        .tada .p {
          position:absolute; left:50%; top:46%; opacity:0;
          animation: burst 1100ms cubic-bezier(.15,.7,.3,1) forwards;
        }
        @keyframes burst {
          0%   { transform: translate(-50%,-50%) rotate(0) scale(.3); opacity:0; }
          12%  { opacity:1; }
          100% { transform: translate(calc(-50% + var(--dx)), calc(-50% + var(--dy)))
                            rotate(var(--rot)) scale(1); opacity:0; }
        }
        .msg {
          position:absolute; left:50%; top:44%; transform:translate(-50%,-50%);
          display:flex; flex-direction:column; align-items:center; gap:5px;
          padding:13px 20px; border-radius:16px; white-space:nowrap; z-index:7;
          background:rgba(255,255,255,.93);
          box-shadow:0 14px 34px rgba(20,60,110,.32);
          border:1px solid rgba(255,255,255,.85);
          opacity:0; animation: cheerPop 2000ms ease forwards;
        }
        .msg .cheer { font-size:20px; font-weight:800; color:#1f7ad0; }
        .msg .goal { font-size:13.5px; font-weight:700; color:#2a4a66; }
        .msg .goal.reached { color:#1e8f4e; }
        @keyframes cheerPop {
          0%   { opacity:0; transform:translate(-50%,-50%) scale(.5); }
          14%  { opacity:1; transform:translate(-50%,-52%) scale(1.06); }
          24%  {            transform:translate(-50%,-50%) scale(1); }
          82%  { opacity:1; transform:translate(-50%,-50%) scale(1); }
          100% { opacity:0; transform:translate(-50%,-58%) scale(.98); }
        }
      </style>

      <div class="wrap" role="alertdialog" aria-label="Drink water reminder">
        <div class="stage">
          <video class="buddy" autoplay muted loop playsinline
                 aria-label="Your water buddy"></video>
        </div>
        <div class="btns">
          <button class="act done" id="done">✓ Done</button>
          <button class="act snooze" id="snooze">😴 Snooze ${snoozeMinutes}m</button>
        </div>
      </div>
    `;

    document.documentElement.appendChild(host);

    // transparent WebM (VP9 alpha) — loops seamlessly in <video>, no WebP blink
    const buddyEl = root.querySelector(".buddy");
    buddyEl.src = buddyUrl;
    buddyEl.play().catch(() => {});

    const wrap = root.querySelector(".wrap");
    // Use setTimeout (not requestAnimationFrame): rAF is paused in background
    // tabs, and a reminder can fire while the page isn't focused — the overlay
    // must still animate in reliably.
    setTimeout(() => {
      wrap.classList.add("in");
    }, 30);
    if (sound) playChime();

    // ---- celebration: she walks off (middle -> right) + a "tada" star burst ----
    let acted = false;
    function launchTada(kind) {
      const stage = root.querySelector(".stage");
      const layer = document.createElement("div");
      layer.className = "tada";
      const emojis = ["✨", "⭐", "🎉", "💫", "🌟", "💧"];
      const N = 18;
      for (let i = 0; i < N; i++) {
        const p = document.createElement("span");
        p.className = "p";
        p.textContent = emojis[i % emojis.length];
        const ang = (Math.PI * 2 * i) / N + i * 0.55;
        const dist = 78 + (i % 5) * 20;
        const dx = Math.cos(ang) * dist;
        const dy = Math.sin(ang) * dist - 26; // bias the burst upward
        p.style.setProperty("--dx", dx.toFixed(0) + "px");
        p.style.setProperty("--dy", dy.toFixed(0) + "px");
        p.style.setProperty("--rot", ((i * 47) % 360) + "deg");
        p.style.fontSize = 16 + (i % 4) * 5 + "px";
        p.style.animationDelay = i * 12 + "ms";
        layer.appendChild(p);
      }
      const msg = document.createElement("div");
      msg.className = "msg";
      const cheer = document.createElement("div");
      cheer.className = "cheer";
      const goalLine = document.createElement("div");
      goalLine.className = "goal";

      if (kind === "done") {
        const done = count + 1; // this glass is now logged
        cheer.textContent = "Well done! 🎉";
        if (done >= goal) {
          goalLine.classList.add("reached");
          goalLine.textContent = `🏆 Goal complete — ${done} glasses!`;
        } else {
          goalLine.textContent = `💧 ${done} of ${goal} glasses — ${goal - done} to go`;
        }
      } else {
        cheer.textContent = "Snoozed 😴";
        goalLine.textContent = `See you in ${snoozeMinutes} min · ${count}/${goal} today`;
      }
      msg.appendChild(cheer);
      msg.appendChild(goalLine);
      layer.appendChild(msg);
      stage.appendChild(layer);
    }

    function celebrateAndClose(kind) {
      if (acted) return;
      acted = true;
      if (autoHideTimer) clearTimeout(autoHideTimer);
      const buddy = root.querySelector(".buddy");
      buddy.classList.add("bye"); // slide from the middle out to the right
      launchTada(kind); // stars burst + "Well done" + glasses/goal message
      setTimeout(removeCard, 2100);
    }

    root.getElementById("done").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "DRANK" }, () => void 0);
      celebrateAndClose("done");
    });
    root.getElementById("snooze").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "SNOOZE" }, () => void 0);
      celebrateAndClose("snooze");
    });
    // gentle auto-dismiss so it never blocks the page forever (pause on hover)
    const startAutoHide = () => {
      autoHideTimer = setTimeout(removeCard, 45000);
    };
    wrap.addEventListener("mouseenter", () => {
      if (autoHideTimer) clearTimeout(autoHideTimer);
    });
    wrap.addEventListener("mouseleave", startAutoHide);
    startAutoHide();
  }

  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg && msg.type === "SHOW_REMINDER") {
      showCard(msg);
      sendResponse && sendResponse({ shown: true });
    }
    return false;
  });
})();
