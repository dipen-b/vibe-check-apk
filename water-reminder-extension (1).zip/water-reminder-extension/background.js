// Sippy — Drink Water Reminder :: service worker (MV3)
// Handles scheduling (interval + fixed custom times), active hours, daily
// reset, snooze, glass logging, and the in-page vs. notification delivery.

const TICK_ALARM = "sippy-tick";

const DEFAULT_SETTINGS = {
  enabled: true,
  intervalMinutes: 60, // interval mode: remind every N minutes
  snoozeMinutes: 10,
  dailyGoal: 8, // glasses per day
  activeStart: "09:00", // don't remind before this
  activeEnd: "21:00", // don't remind after this
  sound: true,
  customTimes: [] // fixed clock reminders e.g. ["12:30","18:00"]
};

function todayKey(d = new Date()) {
  // local YYYY-MM-DD
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function nowHHMM(d = new Date()) {
  return `${String(d.getHours()).padStart(2, "0")}:${String(
    d.getMinutes()
  ).padStart(2, "0")}`;
}

function hhmmToMinutes(s) {
  const [h, m] = (s || "0:0").split(":").map(Number);
  return h * 60 + m;
}

function withinActiveHours(settings, d = new Date()) {
  const cur = d.getHours() * 60 + d.getMinutes();
  const start = hhmmToMinutes(settings.activeStart);
  const end = hhmmToMinutes(settings.activeEnd);
  if (start === end) return true; // 24h
  if (start < end) return cur >= start && cur <= end;
  // overnight window (e.g. 22:00 -> 06:00)
  return cur >= start || cur <= end;
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}

async function saveSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await chrome.storage.local.set({ settings: next });
  return next;
}

async function getState() {
  const { state } = await chrome.storage.local.get("state");
  const base = {
    count: 0,
    date: todayKey(),
    nextAt: 0, // epoch ms for the next interval reminder
    firedTimes: [], // custom times already fired today
    streak: 0,
    lastGoalDate: ""
  };
  return { ...base, ...(state || {}) };
}

async function setState(patch) {
  const cur = await getState();
  const next = { ...cur, ...patch };
  await chrome.storage.local.set({ state: next });
  return next;
}

// Reset the daily counter when the calendar day changes.
async function rolloverIfNeeded(state) {
  const tk = todayKey();
  if (state.date !== tk) {
    // was yesterday's goal met? update streak
    const settings = await getSettings();
    let streak = state.streak || 0;
    if (state.count >= settings.dailyGoal && state.date) {
      streak = streak + 1;
    } else if (state.date) {
      streak = 0;
    }
    state = await setState({
      count: 0,
      date: tk,
      firedTimes: [],
      streak
    });
  }
  return state;
}

// Push the next interval reminder out by N minutes from now.
async function scheduleNext(minutes) {
  const nextAt = Date.now() + minutes * 60 * 1000;
  await setState({ nextAt });
  return nextAt;
}

async function ensureAlarm() {
  const existing = await chrome.alarms.get(TICK_ALARM);
  if (!existing) {
    chrome.alarms.create(TICK_ALARM, { periodInMinutes: 1 });
  }
}

// ---- delivering a reminder --------------------------------------------------

async function deliverReminder() {
  const settings = await getSettings();
  const state = await getState();
  const payload = {
    type: "SHOW_REMINDER",
    count: state.count,
    goal: settings.dailyGoal,
    snoozeMinutes: settings.snoozeMinutes,
    sound: settings.sound
  };

  // Try the focused tab first (in-page animated card).
  const tab = await getActiveTab();
  if (tab && typeof tab.id === "number" && tab.id >= 0 && isInjectable(tab.url)) {
    const shown = await showInTab(tab.id, payload);
    if (shown) return;
  }
  // Couldn't show the in-page card (chrome:// page, web store, no tab…):
  // fall back to a native notification.
  showNotification(state, settings);
}

async function getActiveTab() {
  try {
    let tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tabs && tabs[0]) return tabs[0];
    // no "last focused" window (e.g. popup context) — try current window
    tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs && tabs[0];
  } catch (e) {
    return null;
  }
}

// only web pages can host the overlay
function isInjectable(url) {
  return typeof url === "string" && /^(https?|file):/.test(url);
}

function sendMessageAsync(tabId, payload) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, payload, () => {
        resolve(!chrome.runtime.lastError);
      });
    } catch (e) {
      resolve(false);
    }
  });
}

// Send to the tab's content script; if it isn't there yet (tab was open
// before the extension loaded / just updated), inject it on demand and retry.
async function showInTab(tabId, payload) {
  if (await sendMessageAsync(tabId, payload)) return true;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
  } catch (e) {
    return false; // injection blocked on this page
  }
  return sendMessageAsync(tabId, payload);
}

function showNotification(state, settings) {
  const left = Math.max(0, settings.dailyGoal - state.count);
  const msg =
    left > 0
      ? `${state.count}/${settings.dailyGoal} glasses today — ${left} to go. Time for a sip! 💧`
      : `Goal smashed — ${state.count} glasses! One more won't hurt 💧`;
  chrome.notifications.create("sippy-reminder", {
    type: "basic",
    iconUrl: chrome.runtime.getURL("assets/icon128.png"),
    title: "💧 Time to drink water!",
    message: msg,
    priority: 2,
    requireInteraction: true,
    buttons: [{ title: "💧 I drank it" }, { title: "😴 Snooze" }]
  });
}

// ---- the once-a-minute tick -------------------------------------------------

async function tick() {
  let state = await getState();
  state = await rolloverIfNeeded(state);
  const settings = await getSettings();

  if (!settings.enabled) return;
  if (!withinActiveHours(settings)) return;

  const now = Date.now();
  const d = new Date();
  const curMin = d.getHours() * 60 + d.getMinutes();

  // 1) fixed custom times (fire once per day each). Fire when we're at or just
  // past the set time (0–2 min) so a slightly delayed/coalesced tick still
  // catches it, instead of only matching the exact minute.
  if (Array.isArray(settings.customTimes)) {
    const due = settings.customTimes.find((ct) => {
      if (state.firedTimes.includes(ct)) return false;
      const ctMin = hhmmToMinutes(ct);
      return curMin >= ctMin && curMin - ctMin <= 2;
    });
    if (due) {
      await setState({ firedTimes: [...state.firedTimes, due] });
      await deliverReminder();
      // also push the rolling interval so we don't double-remind immediately
      await scheduleNext(settings.intervalMinutes);
      return;
    }
  }

  // 2) rolling interval
  if (!state.nextAt) {
    await scheduleNext(settings.intervalMinutes);
    return;
  }
  if (now >= state.nextAt) {
    await scheduleNext(settings.intervalMinutes);
    await deliverReminder();
  }
}

// ---- actions ----------------------------------------------------------------

async function logDrink() {
  let state = await getState();
  state = await rolloverIfNeeded(state);
  const settings = await getSettings();
  await setState({ count: state.count + 1 });
  // next reminder resets from "now"
  await scheduleNext(settings.intervalMinutes);
  await refreshBadge();
}

async function snooze() {
  const settings = await getSettings();
  await scheduleNext(settings.snoozeMinutes);
}

async function refreshBadge() {
  const settings = await getSettings();
  const state = await getState();
  if (!settings.enabled) {
    chrome.action.setBadgeText({ text: "" });
    return;
  }
  const left = Math.max(0, settings.dailyGoal - state.count);
  chrome.action.setBadgeBackgroundColor({ color: "#2E8FE6" });
  chrome.action.setBadgeText({ text: left > 0 ? String(left) : "✓" });
}

// ---- wiring -----------------------------------------------------------------

chrome.runtime.onInstalled.addListener(async () => {
  const cur = (await chrome.storage.local.get("settings")).settings;
  if (!cur) await chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
  await getState(); // materialise defaults
  await ensureAlarm();
  const s = await getSettings();
  await scheduleNext(s.intervalMinutes);

  // TESTING: force a 1-minute interval ONE time so scheduled reminders are easy
  // to verify right away. It won't override you again after you change it.
  const flags = await chrome.storage.local.get("testForced");
  if (!flags.testForced) {
    await saveSettings({ intervalMinutes: 1 });
    await scheduleNext(1);
    await chrome.storage.local.set({ testForced: true });
  }

  await refreshBadge();
  await injectExistingTabs(); // so already-open tabs work without a reload
});

// Inject the content script into tabs that were already open before the
// extension was installed / reloaded (declared content scripts only run on
// pages loaded afterwards).
async function injectExistingTabs() {
  try {
    const tabs = await chrome.tabs.query({
      url: ["http://*/*", "https://*/*"]
    });
    for (const t of tabs) {
      if (typeof t.id !== "number") continue;
      chrome.scripting
        .executeScript({ target: { tabId: t.id }, files: ["content.js"] })
        .catch(() => {}); // ignore pages that block injection
    }
  } catch (e) {
    /* no tabs permission / nothing to do */
  }
}

chrome.runtime.onStartup.addListener(async () => {
  await ensureAlarm();
  await refreshBadge();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === TICK_ALARM) {
    tick().then(refreshBadge);
  }
});

chrome.notifications.onButtonClicked.addListener((id, idx) => {
  if (id !== "sippy-reminder") return;
  if (idx === 0) logDrink();
  else snooze();
  chrome.notifications.clear(id);
});
chrome.notifications.onClicked.addListener((id) => {
  if (id === "sippy-reminder") chrome.notifications.clear(id);
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg && msg.type) {
      case "GET_STATE": {
        const settings = await getSettings();
        let state = await getState();
        state = await rolloverIfNeeded(state);
        const msToNext = settings.enabled
          ? Math.max(0, (state.nextAt || 0) - Date.now())
          : null;
        sendResponse({ settings, state, msToNext });
        break;
      }
      case "SAVE_SETTINGS": {
        const wasInterval = (await getSettings()).intervalMinutes;
        const settings = await saveSettings(msg.patch || {});
        // if the interval or enabled flag changed, reschedule cleanly
        if (
          msg.patch &&
          (("intervalMinutes" in msg.patch &&
            msg.patch.intervalMinutes !== wasInterval) ||
            "enabled" in msg.patch)
        ) {
          await scheduleNext(settings.intervalMinutes);
        }
        await ensureAlarm();
        await refreshBadge();
        sendResponse({ ok: true, settings });
        break;
      }
      case "DRANK": {
        await logDrink();
        const settings = await getSettings();
        const state = await getState();
        sendResponse({ ok: true, state, settings });
        break;
      }
      case "SNOOZE": {
        await snooze();
        sendResponse({ ok: true });
        break;
      }
      case "RESET_TODAY": {
        await setState({ count: 0 });
        await refreshBadge();
        sendResponse({ ok: true });
        break;
      }
      case "PREVIEW": {
        await deliverReminder();
        sendResponse({ ok: true });
        break;
      }
      default:
        sendResponse({ ok: false });
    }
  })();
  return true; // keep the message channel open for async sendResponse
});
