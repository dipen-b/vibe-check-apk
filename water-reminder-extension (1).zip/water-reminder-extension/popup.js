// Sippy popup — control panel. Talks to the service worker via messages.
const $ = (id) => document.getElementById(id);
const RING_C = 2 * Math.PI * 52; // matches r=52 in the SVG

let S = null; // settings
let St = null; // state
let msToNext = null;
let countdownTimer = null;

function send(type, extra = {}) {
  return new Promise((res) => chrome.runtime.sendMessage({ type, ...extra }, res));
}

async function refresh() {
  const r = await send("GET_STATE");
  if (!r) return;
  S = r.settings;
  St = r.state;
  msToNext = r.msToNext;
  render();
}

function render() {
  // enable switch
  $("enabled").checked = !!S.enabled;

  // progress ring
  const goal = Math.max(1, S.dailyGoal);
  const pct = Math.min(1, St.count / goal);
  $("count").textContent = St.count;
  $("goalOut").textContent = S.dailyGoal;
  $("goal").textContent = S.dailyGoal;
  const fg = document.querySelector(".ring-fg");
  fg.style.strokeDashoffset = String(RING_C * (1 - pct));
  fg.style.stroke = pct >= 1 ? "#27ae60" : "var(--blue)";

  // settings controls
  $("interval").value = String(S.intervalMinutes);
  $("snooze").value = String(S.snoozeMinutes);
  $("activeStart").value = S.activeStart;
  $("activeEnd").value = S.activeEnd;
  $("sound").checked = !!S.sound;

  // streak
  $("streak").textContent =
    St.streak > 0 ? `🔥 ${St.streak}-day streak` : "";

  renderChips();
  renderCountdown();
}

function renderChips() {
  const wrap = $("chips");
  wrap.innerHTML = "";
  const times = (S.customTimes || []).slice().sort();
  if (!times.length) {
    const e = document.createElement("div");
    e.className = "empty";
    e.textContent = "No fixed times yet — add one below.";
    wrap.appendChild(e);
    return;
  }
  times.forEach((t) => {
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.textContent = prettyTime(t);
    const x = document.createElement("button");
    x.textContent = "✕";
    x.title = "Remove";
    x.addEventListener("click", () => removeTime(t));
    chip.appendChild(x);
    wrap.appendChild(chip);
  });
}

function prettyTime(t) {
  const [h, m] = t.split(":").map(Number);
  const ap = h >= 12 ? "PM" : "AM";
  const h12 = ((h + 11) % 12) + 1;
  return `${h12}:${String(m).padStart(2, "0")} ${ap}`;
}

function renderCountdown() {
  if (countdownTimer) clearInterval(countdownTimer);
  const el = $("next");
  if (!S.enabled) {
    el.textContent = "Reminders paused";
    el.classList.add("off");
    return;
  }
  el.classList.remove("off");
  const target = Date.now() + (msToNext || 0);
  const tick = () => {
    let left = Math.max(0, target - Date.now());
    const m = Math.floor(left / 60000);
    const s = Math.floor((left % 60000) / 1000);
    el.textContent =
      left <= 0
        ? "Sippy is on the way… 💧"
        : `Next sip in ${m}:${String(s).padStart(2, "0")}`;
  };
  tick();
  countdownTimer = setInterval(tick, 1000);
}

async function save(patch) {
  const r = await send("SAVE_SETTINGS", { patch });
  if (r && r.settings) {
    S = r.settings;
    // re-pull msToNext so the countdown reflects a rescheduled interval
    const g = await send("GET_STATE");
    if (g) msToNext = g.msToNext;
    render();
  }
}

// ---- events ----------------------------------------------------------------
$("enabled").addEventListener("change", (e) =>
  save({ enabled: e.target.checked })
);
$("interval").addEventListener("change", (e) =>
  save({ intervalMinutes: Number(e.target.value) })
);
$("snooze").addEventListener("change", (e) =>
  save({ snoozeMinutes: Number(e.target.value) })
);
$("sound").addEventListener("change", (e) => save({ sound: e.target.checked }));
$("activeStart").addEventListener("change", (e) =>
  save({ activeStart: e.target.value || "09:00" })
);
$("activeEnd").addEventListener("change", (e) =>
  save({ activeEnd: e.target.value || "21:00" })
);

$("goalUp").addEventListener("click", () =>
  save({ dailyGoal: Math.min(30, S.dailyGoal + 1) })
);
$("goalDown").addEventListener("click", () =>
  save({ dailyGoal: Math.max(1, S.dailyGoal - 1) })
);

$("drink").addEventListener("click", async () => {
  const r = await send("DRANK");
  if (r && r.state) {
    St = r.state;
    S = r.settings || S;
    const g = await send("GET_STATE");
    if (g) msToNext = g.msToNext;
    render();
  }
});

$("preview").addEventListener("click", async () => {
  await send("PREVIEW");
  window.close(); // let the reminder card show on the page
});

$("reset").addEventListener("click", async () => {
  await send("RESET_TODAY");
  refresh();
});

$("addTime").addEventListener("click", () => addTime());
$("newTime").addEventListener("keydown", (e) => {
  if (e.key === "Enter") addTime();
});

function addTime() {
  const v = $("newTime").value;
  if (!v) return;
  const set = new Set(S.customTimes || []);
  set.add(v);
  save({ customTimes: [...set].sort() });
  $("newTime").value = "";
}
function removeTime(t) {
  const list = (S.customTimes || []).filter((x) => x !== t);
  save({ customTimes: list });
}

// initial paint
refresh();
