# Sippy — Drink Water Reminder (Chrome Extension)

A friendly on-screen buddy who **walks in from the bottom-right corner** to remind
you to drink water. She strolls in, takes a sip, and winks at you 💧 — then you can
log the glass or snooze her.

Built as a Manifest V3 Chrome extension using your provided animation. The clip's
black background and watermark were removed and it was re-encoded as a **transparent
WebM (VP9 with alpha)** (`assets/reminder.webm`) — played in a `<video loop>` so it
loops **smoothly with no flicker** (unlike animated WebP, which blinks at the loop).

## Features

- **Minimal reminder** that slides in from the **bottom-right** of the page — just
  the water buddy as a clean **background-free cutout** (no card, panel, or text)
  with two buttons underneath.
- **Two actions:** `✓ Done` and `😴 Snooze`. On either one, the buddy **walks off to
  the right** and a **"Tada!" stars/confetti burst** celebrates, then it disappears.
- A soft **chime** when the reminder appears (can be turned off).
- **Popup control panel** (click the toolbar droplet):
  - Circular **progress ring** — glasses drunk vs. your daily goal.
  - Live **countdown** to the next reminder.
  - **＋ I drank a glass** quick-log button.
  - **On / Off** master switch.
  - **Remind me every** — 15 / 30 / 45 / 60 / 90 / 120 min (change the timing).
  - **Snooze for** — 5 / 10 / 15 / 20 min.
  - **Daily goal** stepper.
  - **Active hours** — start/end so it won't nag you at night.
  - **Chime sound** toggle.
  - **Extra fixed reminders** — add exact clock times (e.g. 12:30, 18:00) on top of
    the interval reminders. Add / remove any time.
  - A daily **streak** counter 🔥.
- **Badge** on the toolbar icon shows glasses left for the day (✓ when the goal is hit).
- **Fallback:** on pages where an overlay can't be injected (e.g. `chrome://` pages,
  the Chrome Web Store, PDFs), it shows a native Chrome notification with the same
  Drink / Snooze buttons.

## Install (load unpacked)

1. Open Chrome and go to `chrome://extensions`.
2. Turn on **Developer mode** (top-right).
3. Click **Load unpacked**.
4. Select this folder: `water-reminder-extension`.
5. Pin the blue droplet icon from the puzzle-piece menu for easy access.

To try it instantly: click the icon → **Preview reminder**. She'll walk in on the
current tab. (Scheduled reminders default to **every 60 min** — lower the interval or
add a fixed time in the popup while testing.)

> Note: A browser extension can only draw inside the browser, not floating on the OS
> desktop. So the reminder appears in the bottom-right of the **active browser tab** —
> which is how every water-reminder extension does it.

### Troubleshooting

- **Reminder / girl not showing?** The card is injected into the current web page.
  It works automatically on already-open tabs (the extension injects itself on
  install). If you had the extension open from an older version, go to
  `chrome://extensions` and click **Reload ↻** on the Sippy card once.
- On pages where an overlay is impossible (`chrome://` pages, the Chrome Web Store,
  the New Tab page, PDFs), the reminder appears as a **native Chrome notification**
  instead — make sure notifications for Chrome are allowed in your OS settings.
- Use **Preview reminder** to confirm everything works without waiting for the timer.

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | MV3 config, permissions, content script, assets |
| `background.js` | Scheduling (interval + fixed times), active hours, daily reset, snooze, notification fallback |
| `content.js` | The bottom-right slide-in reminder card (Shadow DOM, shows the animated WebP) |
| `popup.html/.css/.js` | The control panel / settings |
| `assets/reminder.webm` | Your water-buddy animation — background + watermark removed, transparent (VP9 alpha), seamless loop |
| `assets/icon*.png` | Toolbar / store icons |
| `preview/` | Local demo pages (mock the extension APIs) — **safe to delete** before publishing |

## Adjusting the look

- The reminder card size/colors live at the top of the `<style>` block in
  `content.js` (`.card`, `.stage`).
- The popup theme colors are the CSS variables at the top of `popup.css` (`--blue`, etc.).
