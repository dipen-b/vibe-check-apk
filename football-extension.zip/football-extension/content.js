// Mini Football — a self-playing, AI-driven football match rendered on a
// pitch pinned to the bottom of the page. Players chase, pass, dribble,
// shoot and score on their own; the extension icon toggles the match.
(() => {
  if (window.top !== window) return;        // top frame only
  if (window.__miniFootballLoaded) return;  // guard against double injection
  window.__miniFootballLoaded = true;

  // ---------- constants ----------
  const PITCH_H = 150;          // strip height in px
  const GOAL_HALF = 34;         // half of the goal-mouth height
  const PLAYERS_PER_TEAM = 4;
  const CONTROL_RADIUS = 14;    // how close a player must be to kick the ball
  const KICK_COOLDOWN = 0.45;   // seconds between touches for one player
  const TEAMS = [
    { name: 'RED',  body: '#e74c3c', trim: '#7e1f16', attacksRight: true  },
    { name: 'BLUE', body: '#3b8fdd', trim: '#164e7e', attacksRight: false }
  ];

  // ---------- state ----------
  let host = null, canvas = null, ctx = null, closeBtn = null;
  let raf = 0, timer = 0, running = false, lastT = 0;
  let W = 0, H = PITCH_H, dpr = 1;
  let players = [], ball = null;
  let score = [0, 0];
  let kickoffFreeze = 0;   // seconds left standing still after a goal/kickoff
  let goalFlash = 0;       // seconds left of the GOAL! banner
  let goalScorer = -1;
  let commentary = '';     // short line under the scoreboard
  let commentaryTtl = 0;

  const rand = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);

  // ---------- setup / teardown ----------
  function buildDom() {
    host = document.createElement('div');
    host.id = '__mini-football-pitch';
    Object.assign(host.style, {
      position: 'fixed', left: '0', right: '0', bottom: '0',
      height: PITCH_H + 'px', zIndex: '2147483646',
      pointerEvents: 'none', margin: '0', padding: '0',
      background: 'transparent'
    });
    canvas = document.createElement('canvas');
    Object.assign(canvas.style, { width: '100%', height: '100%', display: 'block' });
    host.appendChild(canvas);

    closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    closeBtn.title = 'Hide the match on this tab';
    Object.assign(closeBtn.style, {
      position: 'absolute', top: '6px', right: '8px',
      width: '22px', height: '22px', lineHeight: '18px',
      border: 'none', borderRadius: '50%', cursor: 'pointer',
      background: 'rgba(0,0,0,0.45)', color: '#fff',
      fontSize: '15px', fontFamily: 'sans-serif',
      pointerEvents: 'auto', padding: '0'
    });
    closeBtn.addEventListener('click', stop);
    host.appendChild(closeBtn);

    document.documentElement.appendChild(host);
    ctx = canvas.getContext('2d');
    resize();
    window.addEventListener('resize', resize);
  }

  function resize() {
    if (!canvas) return;
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = host.clientWidth;
    H = PITCH_H;
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    players.forEach(p => { p.x = clamp(p.x, 10, W - 10); });
  }

  // ---------- match setup ----------
  function formationAnchor(team, role) {
    // role 0 = keeper-ish, 1 = defender, 2 = midfielder, 3 = striker
    const xs = [0.06, 0.28, 0.52, 0.72];
    const ys = [0.5, 0.25, 0.75, 0.5];
    const fx = TEAMS[team].attacksRight ? xs[role] : 1 - xs[role];
    return { x: fx * W, y: ys[role] * H };
  }

  function makePlayers() {
    players = [];
    for (let t = 0; t < 2; t++) {
      for (let r = 0; r < PLAYERS_PER_TEAM; r++) {
        const a = formationAnchor(t, r);
        players.push({
          team: t, role: r, number: r + 2,
          x: a.x, y: a.y, vx: 0, vy: 0,
          speed: rand(78, 96),         // px/s, slight individual variance
          cooldown: rand(0, 0.3),
          phase: rand(0, Math.PI * 2)  // for the running-leg wobble
        });
      }
    }
  }

  function resetKickoff(concededBy) {
    ball = { x: W / 2, y: H / 2, vx: 0, vy: 0, spin: 0 };
    players.forEach(p => {
      const a = formationAnchor(p.team, p.role);
      p.x = a.x + rand(-6, 6);
      p.y = a.y + rand(-6, 6);
      p.vx = p.vy = 0;
    });
    // team that conceded restarts: nudge one of their mids onto the ball
    if (concededBy !== undefined) {
      const taker = players.find(p => p.team === concededBy && p.role === 2);
      if (taker) { taker.x = W / 2 - (TEAMS[concededBy].attacksRight ? 20 : -20); taker.y = H / 2; }
    }
    kickoffFreeze = 1.1;
  }

  function say(text, ttl = 2.5) { commentary = text; commentaryTtl = ttl; }

  // ---------- AI ----------
  function nearestToBall(team) {
    let best = null, bestD = Infinity;
    for (const p of players) {
      if (p.team !== team) continue;
      const d = dist(p.x, p.y, ball.x, ball.y);
      if (d < bestD) { bestD = d; best = p; }
    }
    return best;
  }

  function goalX(team) { return TEAMS[team].attacksRight ? W : 0; }

  function tryKick(p, dt) {
    if (p.cooldown > 0 || dist(p.x, p.y, ball.x, ball.y) > CONTROL_RADIUS) return;
    const gx = goalX(p.team), gy = H / 2;
    const distToGoal = Math.abs(gx - ball.x);
    const dir = TEAMS[p.team].attacksRight ? 1 : -1;

    if (distToGoal < W * 0.28) {
      // SHOOT — usually on target, sometimes dragged wide of the post
      const spread = Math.random() < 0.25 ? GOAL_HALF * 1.9 : GOAL_HALF * 0.85;
      const aimY = gy + rand(-spread, spread);
      const d = dist(ball.x, ball.y, gx, aimY) || 1;
      const power = rand(300, 380);
      ball.vx = (gx - ball.x) / d * power;
      ball.vy = (aimY - ball.y) / d * power;
      say(`${TEAMS[p.team].name} #${p.number} shoots!`, 1.5);
    } else {
      // PASS if a teammate is better placed, otherwise dribble on
      const options = players.filter(q =>
        q.team === p.team && q !== p &&
        (q.x - p.x) * dir > 30 &&
        dist(p.x, p.y, q.x, q.y) > 55);
      if (options.length && Math.random() < 0.45) {
        const to = options[Math.floor(Math.random() * options.length)];
        const lead = 18 * dir;
        const d = dist(ball.x, ball.y, to.x + lead, to.y) || 1;
        const power = clamp(d * 2.4, 170, 300);
        ball.vx = (to.x + lead - ball.x) / d * power;
        ball.vy = (to.y - ball.y) / d * power;
        say(`${TEAMS[p.team].name} #${p.number} passes`, 1.2);
      } else {
        // dribble: short knock toward goal with some sideways drift
        const aimY = clamp(ball.y + rand(-40, 40), 15, H - 15);
        const d = dist(ball.x, ball.y, gx, aimY) || 1;
        ball.vx = (gx - ball.x) / d * 150;
        ball.vy = (aimY - ball.y) / d * 150;
      }
    }
    ball.spin = rand(-6, 6);
    p.cooldown = KICK_COOLDOWN;
  }

  function steer(p, tx, ty, maxSpeed, dt) {
    const d = dist(p.x, p.y, tx, ty);
    if (d < 2) { p.vx *= 0.8; p.vy *= 0.8; return; }
    const desiredX = (tx - p.x) / d * maxSpeed;
    const desiredY = (ty - p.y) / d * maxSpeed;
    // ease toward the desired velocity so movement looks organic
    p.vx += (desiredX - p.vx) * Math.min(1, dt * 6);
    p.vy += (desiredY - p.vy) * Math.min(1, dt * 6);
  }

  function updatePlayers(dt) {
    const chasers = [nearestToBall(0), nearestToBall(1)];
    for (const p of players) {
      p.cooldown = Math.max(0, p.cooldown - dt);

      if (chasers.includes(p)) {
        // intercept: aim slightly ahead of the ball
        steer(p, ball.x + ball.vx * 0.15, ball.y + ball.vy * 0.15, p.speed, dt);
        tryKick(p, dt);
      } else if (p.role === 0) {
        // goalkeeper: stay on the goal line and track the ball to block shots
        const gx = TEAMS[p.team].attacksRight ? 26 : W - 26;
        const gy = clamp(ball.y, H / 2 - GOAL_HALF - 4, H / 2 + GOAL_HALF + 4);
        steer(p, gx, gy, p.speed * 0.9, dt);
        tryKick(p, dt); // the "save": boots the ball clear when it arrives
      } else {
        // hold formation, shifted toward wherever the ball is
        const a = formationAnchor(p.team, p.role);
        const tx = clamp(a.x + (ball.x - W / 2) * 0.3, 12, W - 12);
        const ty = clamp(a.y + (ball.y - H / 2) * 0.35, 12, H - 12);
        steer(p, tx, ty, p.speed * 0.62, dt);
        tryKick(p, dt); // opportunistic touch if the ball rolls past
      }

      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.x = clamp(p.x, 8, W - 8);
      p.y = clamp(p.y, 8, H - 8);
      p.phase += dt * (6 + Math.hypot(p.vx, p.vy) * 0.12);
    }

    // gentle separation so players don't stack on one spot
    for (let i = 0; i < players.length; i++) {
      for (let j = i + 1; j < players.length; j++) {
        const a = players[i], b = players[j];
        const d = dist(a.x, a.y, b.x, b.y);
        if (d > 0 && d < 20) {
          const push = (20 - d) / d * 0.5;
          const px = (a.x - b.x) * push, py = (a.y - b.y) * push;
          a.x += px; a.y += py; b.x -= px; b.y -= py;
        }
      }
    }
  }

  function updateBall(dt) {
    ball.x += ball.vx * dt;
    ball.y += ball.vy * dt;
    const friction = Math.pow(0.35, dt); // heavy grass friction
    ball.vx *= friction;
    ball.vy *= friction;
    ball.spin *= friction;

    // top/bottom touchlines
    if (ball.y < 8)      { ball.y = 8;     ball.vy = Math.abs(ball.vy) * 0.75; }
    if (ball.y > H - 8)  { ball.y = H - 8; ball.vy = -Math.abs(ball.vy) * 0.75; }

    // goal lines: goal if within the mouth, otherwise rebound
    const inMouth = Math.abs(ball.y - H / 2) < GOAL_HALF;
    if (ball.x < 7) {
      if (inMouth) return scoreGoal(1); // blue attacks left? no — see below
      ball.x = 7; ball.vx = Math.abs(ball.vx) * 0.75;
    }
    if (ball.x > W - 7) {
      if (inMouth) return scoreGoal(0);
      ball.x = W - 7; ball.vx = -Math.abs(ball.vx) * 0.75;
    }
  }

  // team RED attacks right, so ball crossing the RIGHT line is a RED goal (index 0);
  // crossing the LEFT line is a BLUE goal (index 1).
  function scoreGoal(team) {
    score[team]++;
    goalFlash = 2.2;
    goalScorer = team;
    say(`GOAL! ${TEAMS[team].name} lead the play`, 2.5);
    resetKickoff(1 - team);
  }

  // ---------- rendering ----------
  function drawPitch() {
    // Fully transparent pitch: no background at all, only the field markings.
    // Every line is drawn twice — a wide dark under-stroke then a thin white
    // stroke — so the markings stay readable on light AND dark pages.
    const mark = draw => {
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,0.35)'; draw();
      ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(255,255,255,0.9)'; draw();
    };
    // boundary
    mark(() => ctx.strokeRect(6, 6, W - 12, H - 12));
    // halfway line + centre circle
    mark(() => { ctx.beginPath(); ctx.moveTo(W / 2, 6); ctx.lineTo(W / 2, H - 6); ctx.stroke(); });
    mark(() => { ctx.beginPath(); ctx.arc(W / 2, H / 2, 28, 0, Math.PI * 2); ctx.stroke(); });
    // penalty boxes
    const boxH = GOAL_HALF * 2 + 30;
    mark(() => ctx.strokeRect(6, H / 2 - boxH / 2, 52, boxH));
    mark(() => ctx.strokeRect(W - 58, H / 2 - boxH / 2, 52, boxH));
    // goal mouths (dark backing + white face, same contrast trick)
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(0, H / 2 - GOAL_HALF - 2, 8, GOAL_HALF * 2 + 4);
    ctx.fillRect(W - 8, H / 2 - GOAL_HALF - 2, 8, GOAL_HALF * 2 + 4);
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillRect(0, H / 2 - GOAL_HALF, 6, GOAL_HALF * 2);
    ctx.fillRect(W - 6, H / 2 - GOAL_HALF, 6, GOAL_HALF * 2);
  }

  function drawPlayer(p) {
    const t = TEAMS[p.team];
    // shadow
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.beginPath(); ctx.ellipse(p.x, p.y + 6, 7, 3, 0, 0, Math.PI * 2); ctx.fill();
    // running legs (two little pumping dots)
    const legSwing = Math.sin(p.phase) * 4 * Math.min(1, Math.hypot(p.vx, p.vy) / 40);
    ctx.fillStyle = t.trim;
    ctx.beginPath(); ctx.arc(p.x - 3, p.y + 5 + legSwing, 2.2, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(p.x + 3, p.y + 5 - legSwing, 2.2, 0, Math.PI * 2); ctx.fill();
    // body
    ctx.fillStyle = t.body;
    ctx.strokeStyle = t.trim;
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(p.x, p.y, 7, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    // shirt number
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 7px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(String(p.number), p.x, p.y);
  }

  function drawBall() {
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.beginPath(); ctx.ellipse(ball.x, ball.y + 5, 4.5, 2, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(ball.x, ball.y, 4.5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    // rotating seam mark so movement reads as rolling
    const a = ball.spin + (ball.x + ball.y) * 0.15;
    ctx.strokeStyle = '#333';
    ctx.beginPath();
    ctx.moveTo(ball.x + Math.cos(a) * 3.5, ball.y + Math.sin(a) * 3.5);
    ctx.lineTo(ball.x - Math.cos(a) * 3.5, ball.y - Math.sin(a) * 3.5);
    ctx.stroke();
  }

  function drawHud() {
    // scoreboard pill
    const text = `${TEAMS[0].name} ${score[0]}  :  ${score[1]} ${TEAMS[1].name}`;
    ctx.font = 'bold 12px sans-serif';
    const w = ctx.measureText(text).width + 26;
    ctx.fillStyle = 'rgba(10,26,16,0.8)';
    roundRect(W / 2 - w / 2, 10, w, 20, 10); ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(text, W / 2, 20);

    if (commentaryTtl > 0 && commentary) {
      ctx.font = '10px sans-serif';
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(0,0,0,0.55)';
      ctx.strokeText(commentary, W / 2, 38);
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.fillText(commentary, W / 2, 38);
    }

    if (goalFlash > 0) {
      const pulse = 1 + Math.sin(goalFlash * 12) * 0.08;
      ctx.save();
      ctx.translate(W / 2, H / 2);
      ctx.scale(pulse, pulse);
      ctx.font = 'bold 34px sans-serif';
      ctx.lineWidth = 5;
      ctx.strokeStyle = 'rgba(0,0,0,0.55)';
      ctx.fillStyle = goalScorer >= 0 ? TEAMS[goalScorer].body : '#fff';
      ctx.strokeText('GOAL!', 0, 0);
      ctx.fillText('GOAL!', 0, 0);
      ctx.restore();
    }
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  // ---------- main loop ----------
  function stepSim(dt) {
    goalFlash = Math.max(0, goalFlash - dt);
    commentaryTtl = Math.max(0, commentaryTtl - dt);

    if (kickoffFreeze > 0) {
      kickoffFreeze -= dt;
    } else {
      updatePlayers(dt);
      if (ball) updateBall(dt);
    }
  }

  function frame(t) {
    if (!running) return;
    // Timers get throttled in background tabs, so a single tick may cover a
    // long stretch of wall time. Advance the simulation in fixed sub-steps so
    // the match keeps real-time pace without physics blowing up.
    let elapsed = (t - lastT) / 1000 || 0.016;
    lastT = t;
    elapsed = Math.min(elapsed, 2);
    const steps = Math.max(1, Math.min(120, Math.round(elapsed / 0.016)));
    const dt = elapsed / steps;
    for (let i = 0; i < steps; i++) stepSim(Math.min(dt, 0.05));

    ctx.clearRect(0, 0, W, H);
    drawPitch();
    players.forEach(drawPlayer);
    if (ball) drawBall();
    drawHud();

    // lightweight state probe (isolated world in the real extension; handy in demo)
    window.__miniFootballDebug = {
      frames: (window.__miniFootballDebug ? window.__miniFootballDebug.frames : 0) + 1,
      ball: ball && { x: Math.round(ball.x), y: Math.round(ball.y) },
      score: score.slice(), kickoffFreeze, running
    };

    scheduleNext();
  }

  // rAF is suspended in hidden/background tabs; fall back to a timer there
  // so the match keeps playing and the pitch is painted when you come back.
  function scheduleNext() {
    if (!running) return;
    if (document.hidden) {
      raf = 0;
      timer = setTimeout(() => frame(performance.now()), 66);
    } else {
      raf = requestAnimationFrame(frame);
    }
  }

  document.addEventListener('visibilitychange', () => {
    if (!running) return;
    clearTimeout(timer);
    if (raf) cancelAnimationFrame(raf);
    lastT = performance.now();
    scheduleNext();
  });

  // ---------- lifecycle ----------
  function start() {
    if (running) return;
    if (!host) buildDom();
    host.style.display = 'block';
    resize();
    score = [0, 0];
    makePlayers();
    resetKickoff();
    say('Kick-off!', 2);
    running = true;
    lastT = performance.now();
    frame(lastT); // paint immediately, then keep scheduling itself
  }

  function stop() {
    running = false;
    if (raf) cancelAnimationFrame(raf);
    clearTimeout(timer);
    if (host) host.style.display = 'none';
  }

  // ---------- extension wiring ----------
  function applyEnabled(enabled) { enabled ? start() : stop(); }

  try {
    chrome.storage.local.get({ footballEnabled: false }, res => {
      applyEnabled(!!(res && res.footballEnabled));
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.footballEnabled) {
        applyEnabled(!!changes.footballEnabled.newValue);
      }
    });
  } catch (e) {
    // Not running as an extension (e.g. the demo page) — start immediately.
    start();
  }
})();
