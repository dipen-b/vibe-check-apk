# Mini Football — Bottom Pitch (Chrome Extension)

A Chrome extension that plays a live, self-running football match on a green
pitch pinned to the bottom of every tab. Eight AI players (RED vs BLUE, 4 a
side) chase, pass, dribble, shoot and score entirely on their own — every
match plays out differently.

## Features

- **Dynamic AI gameplay** — each team's nearest player hunts the ball while
  teammates hold a shifting formation; players decide per touch whether to
  shoot (near goal), pass to a better-placed teammate, or dribble on.
- **Real match flow** — goals, animated `GOAL!` banner, live scoreboard,
  short commentary lines, kickoff resets after every goal.
- **One-click toggle** — click the toolbar icon: badge turns **ON** and the
  match kicks off on all open tabs instantly; click again to stop everywhere.
- **Unobtrusive** — the pitch is click-through (`pointer-events: none`), so
  the page underneath stays fully usable. A small `×` hides it per tab.

## Install (Developer mode)

1. Open Chrome and go to `chrome://extensions`.
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked** and select this `football-extension` folder.
4. Click the extension icon in the toolbar — the badge shows **ON** and the
   match starts at the bottom of your tabs. Click again to stop.

> Tabs that were already open before installing need one refresh to receive
> the content script.

## Try it without installing

Open `demo.html` in any browser — it loads the same game code with the
extension APIs stubbed out, so the match starts immediately.

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | Manifest V3 definition (action button, storage, content script) |
| `background.js` | Service worker — flips the global on/off flag and badge |
| `content.js` | The whole game: pitch rendering, physics, player AI, HUD |
| `demo.html` | Standalone preview page (no install needed) |
| `icons/` | Toolbar/store icons |
