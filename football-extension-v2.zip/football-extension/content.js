// Mini Football — El Clásico Edition. A self-playing, AI-driven Barça vs
// Madrid match rendered on a grass pitch pinned to the bottom of the page.
// Players chase, pass, dribble, shoot and score on their own; the extension
// icon toggles the match. Real-player sprites live in players/*.png.
(() => {
  if (window.top !== window) return;        // top frame only
  if (window.__miniFootballLoaded) return;  // guard against double injection
  window.__miniFootballLoaded = true;

  // ---------- constants ----------
  const PITCH_H = 200;          // strip height in px (tall enough for sprites)
  const AD_H = 12;              // slim stadium "ad board" band along the top edge
  const FIELD_TOP = 20;         // playable boundary starts below the ad board
  const GOAL_HALF = 34;         // half of the goal-mouth height
  const PLAYERS_PER_TEAM = 5;
  const CONTROL_RADIUS = 16;    // how close a player must be to kick the ball
  const KICK_COOLDOWN = 0.45;   // seconds between touches for one player
  const SPRITE_H = 52;          // face-token diameter on the pitch, in px
  const BALL_R = 7;
  const PY_MIN = 44;            // keep tokens clear of the ad board on top
  const PY_MAX = PITCH_H - 14;
  // vertical centre of the playable field (between the ad board and bottom
  // line) — every line, goal mouth, physics bound and AI target uses this so
  // the whole game stays consistent with the offset boundary.
  const MID_Y = (FIELD_TOP + PITCH_H - 6) / 2;

  // Two 5-a-side squads. Roles: 0 = keeper-ish deep man, 1 = defender,
  // 2 = midfielder, 3 = midfielder/winger, 4 = striker. `num` is the text
  // color inside the number badge (white shirts need dark digits).
  const TEAMS = [
    {
      name: 'BARÇA', body: '#a50044', trim: '#004d98', num: '#ffffff',
      attacksRight: true,
      squad: [
        { sprite: 'barca-lewa2.png',    pname: 'Lewandowski', number: 9  },
        { sprite: 'barca-pedri.png',    pname: 'Pedri',       number: 8  },
        { sprite: 'barca-lewa.png',     pname: 'Lewandowski', number: 9  },
        { sprite: 'barca-raphinha.png', pname: 'Raphinha',    number: 11 },
        { sprite: 'barca-messi.png',    pname: 'Messi',       number: 10 }
      ]
    },
    {
      name: 'MADRID', body: '#ffffff', trim: '#00529f', num: '#00529f',
      attacksRight: false,
      squad: [
        { sprite: 'real-taa.png',      pname: 'Alexander-Arnold', number: 12 },
        { sprite: 'real-zidane.png',   pname: 'Zidane',           number: 5  },
        { sprite: 'real-valverde.png', pname: 'Valverde',         number: 8  },
        { sprite: 'real-ronaldo.png',  pname: 'Ronaldo',          number: 7  },
        { sprite: 'real-benzema.png',  pname: 'Benzema',          number: 9  }
      ]
    }
  ];

  // ---------- state ----------
  let host = null, canvas = null, ctx = null, closeBtn = null;
  let raf = 0, timer = 0, running = false, lastT = 0;
  let W = 0, H = PITCH_H, dpr = 1;
  let players = [], ball = null;
  let score = [0, 0];
  let kickoffFreeze = 0;   // seconds left standing still after a goal/kickoff
  let goalFlash = 0;       // seconds left of the GOAL! banner
  let goalScorer = -1;
  let lastKicker = null;   // last player to touch the ball (credits the goal)
  let commentary = '';     // short line under the scoreboard
  let commentaryTtl = 0;
  let matchClock = 0;      // running match time in seconds (broadcast clock)
  let grassTex = null;     // pre-generated speckle pattern (built once)

  const rand = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);

  // ---------- sprites ----------
  // Load each portrait once. Inside the extension the files come from
  // chrome.runtime.getURL; on a plain page (demo.html) that throws, so we
  // fall back to a relative path. Until an image has actually decoded we
  // keep drawing the old colored dot, so the game never breaks.
  const sprites = {};
  function spriteUrl(file) {
    try { return chrome.runtime.getURL('players/' + file); }
    catch (e) { return 'players/' + file; }
  }
  function loadSprites() {
    for (const team of TEAMS) {
      for (const s of team.squad) {
        if (sprites[s.sprite]) continue;
        const img = new Image();
        img.src = spriteUrl(s.sprite);
        sprites[s.sprite] = img;
      }
    }
  }
  const spriteReady = img => !!(img && img.complete && img.naturalWidth > 0);

  // Pre-scaled sprite cache. Downscaling a big PNG in drawImage every frame
  // is what made players look blurry; instead each portrait is resampled ONCE
  // into an offscreen canvas at exactly the on-screen size × dpr (with high
  // quality smoothing) and then blitted 1:1 on integer device pixels.
  const spriteCache = {};
  function cachedSprite(file) {
    const img = sprites[file];
    if (!spriteReady(img)) return null;
    // key catches dpr changes AND the PNGs being swapped for new dimensions
    const key = dpr + '/' + SPRITE_H + '/' + img.naturalWidth + 'x' + img.naturalHeight;
    let c = spriteCache[file];
    if (c && c.key === key) return c;
    const cssW = SPRITE_H * (img.naturalWidth / img.naturalHeight);
    const cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(cssW * dpr));
    cv.height = Math.max(1, Math.round(SPRITE_H * dpr));
    const cc = cv.getContext('2d');
    cc.imageSmoothingEnabled = true;
    cc.imageSmoothingQuality = 'high';
    cc.drawImage(img, 0, 0, cv.width, cv.height);
    c = { canvas: cv, cssW, key };
    spriteCache[file] = c;
    return c;
  }

  // ---------- setup / teardown ----------
  function buildDom() {
    host = document.createElement('div');
    host.id = '__mini-football-pitch';
    Object.assign(host.style, {
      position: 'fixed', left: '0', right: '0', bottom: '0',
      height: PITCH_H + 'px', zIndex: '2147483646',
      pointerEvents: 'none', margin: '0', padding: '0',
      background: 'transparent',
      // a soft lift above the strip so the opaque pitch separates cleanly
      // from the page in both light and dark mode
      boxShadow: '0 -4px 14px rgba(0,0,0,0.35)'
    });
    canvas = document.createElement('canvas');
    Object.assign(canvas.style, { width: '100%', height: '100%', display: 'block' });
    host.appendChild(canvas);

    closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    closeBtn.title = 'Hide the match on this tab';
    Object.assign(closeBtn.style, {
      position: 'absolute', top: '6px', right: '8px',
      width: '22px', height: '22px', lineHeight: '18px',
      border: 'none', borderRadius: '50%', cursor: 'pointer',
      background: 'rgba(0,0,0,0.45)', color: '#fff',
      fontSize: '15px', fontFamily: 'sans-serif',
      pointerEvents: 'auto', padding: '0'
    });
    closeBtn.addEventListener('click', stop);
    host.appendChild(closeBtn);

    document.documentElement.appendChild(host);
    ctx = canvas.getContext('2d');
    resize();
    window.addEventListener('resize', resize);
  }

  function resize() {
    if (!canvas) return;
    const oldDpr = dpr;
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = host.clientWidth;
    H = PITCH_H;
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    // resizing the backing store resets context state — re-assert smoothing
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    // pre-scaled sprites are baked at a specific dpr; rebuild on change
    if (dpr !== oldDpr) for (const k in spriteCache) delete spriteCache[k];
    players.forEach(p => { p.x = clamp(p.x, 30, W - 30); });
  }

  // ---------- match setup ----------
  function formationAnchor(team, role) {
    // role 0 = keeper-ish deep man … 4 = striker (see TEAMS squads)
    const xs = [0.05, 0.22, 0.42, 0.60, 0.76];
    const ys = [0.5, 0.3, 0.7, 0.25, 0.6];
    const fx = TEAMS[team].attacksRight ? xs[role] : 1 - xs[role];
    // spread ys across the playable field (below the ad board), not raw H
    const fy = FIELD_TOP + ys[role] * (H - 6 - FIELD_TOP);
    return { x: fx * W, y: clamp(fy, PY_MIN, PY_MAX) };
  }

  function makePlayers() {
    players = [];
    for (let t = 0; t < 2; t++) {
      for (let r = 0; r < PLAYERS_PER_TEAM; r++) {
        const a = formationAnchor(t, r);
        const info = TEAMS[t].squad[r];
        players.push({
          team: t, role: r,
          name: info.pname, number: info.number, sprite: info.sprite,
          x: a.x, y: a.y, vx: 0, vy: 0,
          speed: rand(78, 96),         // px/s, slight individual variance
          cooldown: rand(0, 0.3),
          phase: rand(0, Math.PI * 2)  // for the running bob
        });
      }
    }
  }

  function resetKickoff(concededBy) {
    ball = { x: W / 2, y: MID_Y, vx: 0, vy: 0, spin: 0, rot: 0 };
    players.forEach(p => {
      const a = formationAnchor(p.team, p.role);
      p.x = a.x + rand(-6, 6);
      p.y = clamp(a.y + rand(-6, 6), PY_MIN, PY_MAX);
      p.vx = p.vy = 0;
    });
    // team that conceded restarts: nudge one of their mids onto the ball
    if (concededBy !== undefined) {
      const taker = players.find(p => p.team === concededBy && p.role === 2);
      if (taker) { taker.x = W / 2 - (TEAMS[concededBy].attacksRight ? 20 : -20); taker.y = MID_Y; }
    }
    lastKicker = null;
    kickoffFreeze = 1.1;
  }

  function say(text, ttl = 2.5) { commentary = text; commentaryTtl = ttl; }

  // ---------- AI ----------
  function nearestToBall(team) {
    let best = null, bestD = Infinity;
    for (const p of players) {
      if (p.team !== team) continue;
      const d = dist(p.x, p.y, ball.x, ball.y);
      if (d < bestD) { bestD = d; best = p; }
    }
    return best;
  }

  function goalX(team) { return TEAMS[team].attacksRight ? W : 0; }

  function tryKick(p, dt) {
    if (p.cooldown > 0 || dist(p.x, p.y, ball.x, ball.y) > CONTROL_RADIUS) return;
    const gx = goalX(p.team), gy = MID_Y;
    const distToGoal = Math.abs(gx - ball.x);
    const dir = TEAMS[p.team].attacksRight ? 1 : -1;

    if (distToGoal < W * 0.28) {
      // SHOOT — usually on target, sometimes dragged wide of the post
      const spread = Math.random() < 0.25 ? GOAL_HALF * 1.9 : GOAL_HALF * 0.85;
      const aimY = gy + rand(-spread, spread);
      const d = dist(ball.x, ball.y, gx, aimY) || 1;
      const power = rand(300, 380);
      ball.vx = (gx - ball.x) / d * power;
      ball.vy = (aimY - ball.y) / d * power;
      say(`${p.name} shoots!`, 1.5);
    } else {
      // PASS if a teammate is better placed, otherwise dribble on
      const options = players.filter(q =>
        q.team === p.team && q !== p &&
        (q.x - p.x) * dir > 30 &&
        dist(p.x, p.y, q.x, q.y) > 55);
      if (options.length && Math.random() < 0.45) {
        const to = options[Math.floor(Math.random() * options.length)];
        const lead = 18 * dir;
        const d = dist(ball.x, ball.y, to.x + lead, to.y) || 1;
        const power = clamp(d * 2.4, 170, 300);
        ball.vx = (to.x + lead - ball.x) / d * power;
        ball.vy = (to.y - ball.y) / d * power;
        say(`${p.name} finds ${to.name}`, 1.2);
      } else {
        // dribble: short knock toward goal with some sideways drift
        const aimY = clamp(ball.y + rand(-40, 40), FIELD_TOP + 9, H - 15);
        const d = dist(ball.x, ball.y, gx, aimY) || 1;
        ball.vx = (gx - ball.x) / d * 150;
        ball.vy = (aimY - ball.y) / d * 150;
      }
    }
    ball.spin = rand(-6, 6);
    lastKicker = p;
    p.cooldown = KICK_COOLDOWN;
  }

  function steer(p, tx, ty, maxSpeed, dt) {
    const d = dist(p.x, p.y, tx, ty);
    if (d < 2) { p.vx *= 0.8; p.vy *= 0.8; return; }
    const desiredX = (tx - p.x) / d * maxSpeed;
    const desiredY = (ty - p.y) / d * maxSpeed;
    // ease toward the desired velocity so movement looks organic
    p.vx += (desiredX - p.vx) * Math.min(1, dt * 6);
    p.vy += (desiredY - p.vy) * Math.min(1, dt * 6);
  }

  function updatePlayers(dt) {
    const chasers = [nearestToBall(0), nearestToBall(1)];
    for (const p of players) {
      p.cooldown = Math.max(0, p.cooldown - dt);

      if (chasers.includes(p)) {
        // intercept: aim slightly ahead of the ball
        steer(p, ball.x + ball.vx * 0.15, ball.y + ball.vy * 0.15, p.speed, dt);
        tryKick(p, dt);
      } else if (p.role === 0) {
        // goalkeeper: stay on the goal line and track the ball to block shots
        const gx = TEAMS[p.team].attacksRight ? 26 : W - 26;
        const gy = clamp(ball.y, MID_Y - GOAL_HALF - 4, MID_Y + GOAL_HALF + 4);
        steer(p, gx, gy, p.speed * 0.9, dt);
        tryKick(p, dt); // the "save": boots the ball clear when it arrives
      } else {
        // hold formation, shifted toward wherever the ball is
        const a = formationAnchor(p.team, p.role);
        const tx = clamp(a.x + (ball.x - W / 2) * 0.3, 12, W - 12);
        const ty = clamp(a.y + (ball.y - MID_Y) * 0.35, PY_MIN, PY_MAX);
        steer(p, tx, ty, p.speed * 0.62, dt);
        tryKick(p, dt); // opportunistic touch if the ball rolls past
      }

      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.x = clamp(p.x, 30, W - 30); // keep the whole face token on screen
      p.y = clamp(p.y, PY_MIN, PY_MAX);
      p.phase += dt * (6 + Math.hypot(p.vx, p.vy) * 0.12);
    }

    // gentle separation so players don't stack on one spot
    for (let i = 0; i < players.length; i++) {
      for (let j = i + 1; j < players.length; j++) {
        const a = players[i], b = players[j];
        const d = dist(a.x, a.y, b.x, b.y);
        if (d > 0 && d < 20) {
          const push = (20 - d) / d * 0.5;
          const px = (a.x - b.x) * push, py = (a.y - b.y) * push;
          a.x += px; a.y += py; b.x -= px; b.y -= py;
        }
      }
    }
  }

  function updateBall(dt) {
    ball.x += ball.vx * dt;
    ball.y += ball.vy * dt;
    const friction = Math.pow(0.35, dt); // heavy grass friction
    ball.vx *= friction;
    ball.vy *= friction;
    ball.spin *= friction;
    // roll: angular travel = linear travel / radius, signed by direction
    const speed = Math.hypot(ball.vx, ball.vy);
    ball.rot += (speed / BALL_R) * dt * (ball.vx < 0 ? -1 : 1) * 0.5;

    // top/bottom touchlines (top one sits below the ad board)
    const topLim = FIELD_TOP + 2;
    if (ball.y < topLim) { ball.y = topLim; ball.vy = Math.abs(ball.vy) * 0.75; }
    if (ball.y > H - 8)  { ball.y = H - 8;  ball.vy = -Math.abs(ball.vy) * 0.75; }

    // goal lines: goal if within the mouth, otherwise rebound
    const inMouth = Math.abs(ball.y - MID_Y) < GOAL_HALF;
    if (ball.x < 7) {
      if (inMouth) return scoreGoal(1); // Madrid attack the LEFT goal
      ball.x = 7; ball.vx = Math.abs(ball.vx) * 0.75;
    }
    if (ball.x > W - 7) {
      if (inMouth) return scoreGoal(0);
      ball.x = W - 7; ball.vx = -Math.abs(ball.vx) * 0.75;
    }
  }

  // BARÇA attacks right, so ball crossing the RIGHT line is a BARÇA goal
  // (index 0); crossing the LEFT line is a MADRID goal (index 1).
  function scoreGoal(team) {
    score[team]++;
    goalFlash = 2.2;
    goalScorer = team;
    if (lastKicker && lastKicker.team === team) {
      say(`GOAL! ${lastKicker.name} scores for ${TEAMS[team].name}!`, 2.8);
    } else if (lastKicker) {
      say(`GOAL! Own goal by ${lastKicker.name} — ${TEAMS[team].name} profit!`, 2.8);
    } else {
      say(`GOAL! ${TEAMS[team].name} strike!`, 2.8);
    }
    resetKickoff(1 - team);
  }

  // ---------- rendering ----------
  // A tiny speckle tile built ONCE with a seeded loop (no per-frame random)
  // and repeated over the gradient at low alpha — reads as grass blades.
  function grassPattern() {
    if (grassTex) return grassTex;
    const cv = document.createElement('canvas');
    cv.width = cv.height = 96;
    const cc = cv.getContext('2d');
    let seed = 1234567;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < 900; i++) {
      const x = rnd() * 96, y = rnd() * 96;
      cc.fillStyle = rnd() < 0.5 ? 'rgba(0,30,10,0.6)' : 'rgba(220,255,220,0.6)';
      cc.fillRect(x, y, 1.3, 1.3);
    }
    grassTex = ctx.createPattern(cv, 'repeat');
    return grassTex;
  }

  function drawPitch() {
    // Opaque "real" grass so the pitch reads clearly on light AND dark pages.
    const grass = ctx.createLinearGradient(0, 0, 0, H);
    grass.addColorStop(0, '#2f9e44');
    grass.addColorStop(1, '#1e7a33');
    ctx.fillStyle = grass;
    ctx.fillRect(0, 0, W, H);
    // very subtle blade speckle under the stripes
    ctx.save();
    ctx.globalAlpha = 0.09;
    ctx.fillStyle = grassPattern();
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
    // alternating mowing stripes
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    for (let x = 0; x < W; x += 160) ctx.fillRect(x, 0, 80, H);
    // darker top edge so the strip separates from the page content
    ctx.fillStyle = 'rgba(0,40,12,0.85)';
    ctx.fillRect(0, 0, W, 2);
    // stadium hoardings: a slim dark ad board with faint repeating text
    ctx.fillStyle = 'rgba(8,16,26,0.92)';
    ctx.fillRect(0, 2, W, AD_H);
    ctx.fillStyle = 'rgba(255,255,255,0.28)';
    ctx.font = 'bold 8px sans-serif';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    const ad = 'EL CLÁSICO  •  ';
    const adW = ctx.measureText(ad).width;
    for (let x = 6; x < W; x += adW) ctx.fillText(ad, x, 2 + AD_H / 2 + 0.5);

    // Bold white markings, each drawn twice — a faint dark under-stroke then
    // the white stroke — so lines look crisp on the grass.
    const mark = draw => {
      ctx.lineWidth = 4.5; ctx.strokeStyle = 'rgba(0,55,20,0.35)'; draw();
      ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(255,255,255,0.95)'; draw();
    };
    const spot = (x, y, r = 2.5) => {
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    };
    // boundary (top edge sits below the ad board)
    mark(() => ctx.strokeRect(6, FIELD_TOP, W - 12, H - 6 - FIELD_TOP));
    // halfway line + centre circle + centre spot
    mark(() => { ctx.beginPath(); ctx.moveTo(W / 2, FIELD_TOP); ctx.lineTo(W / 2, H - 6); ctx.stroke(); });
    mark(() => { ctx.beginPath(); ctx.arc(W / 2, MID_Y, 32, 0, Math.PI * 2); ctx.stroke(); });
    spot(W / 2, MID_Y);
    // penalty boxes + 6-yard boxes + penalty spots
    const boxH = GOAL_HALF * 2 + 44, sixH = GOAL_HALF * 2 + 8;
    mark(() => ctx.strokeRect(6, MID_Y - boxH / 2, 62, boxH));
    mark(() => ctx.strokeRect(W - 68, MID_Y - boxH / 2, 62, boxH));
    mark(() => ctx.strokeRect(6, MID_Y - sixH / 2, 26, sixH));
    mark(() => ctx.strokeRect(W - 32, MID_Y - sixH / 2, 26, sixH));
    spot(50, MID_Y);
    spot(W - 50, MID_Y);
    // penalty-arc "D" — the part of a circle around each penalty spot that
    // pokes out past the front edge of the box (x = 68 / W - 68)
    const dR = 24, dA = Math.acos(18 / dR); // 18 = box edge − spot x
    mark(() => { ctx.beginPath(); ctx.arc(50, MID_Y, dR, -dA, dA); ctx.stroke(); });
    mark(() => { ctx.beginPath(); ctx.arc(W - 50, MID_Y, dR, Math.PI - dA, Math.PI + dA); ctx.stroke(); });
    // corner arcs (quarter circles inside each corner of the boundary)
    mark(() => { ctx.beginPath(); ctx.arc(6, FIELD_TOP, 9, 0, Math.PI / 2); ctx.stroke(); });
    mark(() => { ctx.beginPath(); ctx.arc(W - 6, FIELD_TOP, 9, Math.PI / 2, Math.PI); ctx.stroke(); });
    mark(() => { ctx.beginPath(); ctx.arc(W - 6, H - 6, 9, Math.PI, Math.PI * 1.5); ctx.stroke(); });
    mark(() => { ctx.beginPath(); ctx.arc(6, H - 6, 9, Math.PI * 1.5, Math.PI * 2); ctx.stroke(); });
    // corner flags
    drawCornerFlag(6, FIELD_TOP);
    drawCornerFlag(W - 6, FIELD_TOP);
    drawCornerFlag(W - 6, H - 6);
    drawCornerFlag(6, H - 6);

    drawGoal(true);
    drawGoal(false);
  }

  // A short white pole with a tiny colored triangle flag at each corner.
  function drawCornerFlag(x, y) {
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(x, y + 1); ctx.lineTo(x, y - 9); ctx.stroke();
    const dir = x < W / 2 ? 1 : -1; // flags flutter toward the pitch
    ctx.fillStyle = '#ffd43b';
    ctx.beginPath();
    ctx.moveTo(x, y - 9);
    ctx.lineTo(x + 7 * dir, y - 7);
    ctx.lineTo(x, y - 5);
    ctx.closePath();
    ctx.fill();
  }

  // A top-view goal frame: white posts on the goal line and a criss-cross
  // net filling the shallow space behind it.
  function drawGoal(leftSide) {
    const top = MID_Y - GOAL_HALF, bot = MID_Y + GOAL_HALF;
    const x0 = leftSide ? 0 : W - 7;   // net cavity, 7px deep behind the line
    const x1 = leftSide ? 7 : W;
    // net backing
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(x0, top, x1 - x0, bot - top);
    // netting: fine criss-cross lines
    ctx.strokeStyle = 'rgba(255,255,255,0.65)';
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    for (let y = top; y <= bot; y += 4) { ctx.moveTo(x0, y); ctx.lineTo(x1, y); }
    for (let x = x0; x <= x1; x += 3.5) { ctx.moveTo(x, top); ctx.lineTo(x, bot); }
    ctx.stroke();
    // frame: back bar + side bars
    ctx.strokeStyle = 'rgba(255,255,255,0.95)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    const backX = leftSide ? x0 + 1 : x1 - 1;
    ctx.moveTo(backX, top); ctx.lineTo(backX, bot);
    ctx.moveTo(x0, top); ctx.lineTo(x1, top);
    ctx.moveTo(x0, bot); ctx.lineTo(x1, bot);
    ctx.stroke();
    // posts: two bright knobs on the goal line
    const postX = leftSide ? x1 : x0;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.arc(postX, top, 2.6, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(postX, bot, 2.6, 0, Math.PI * 2); ctx.fill();
  }

  function drawPlayer(p) {
    const t = TEAMS[p.team];
    const footX = p.x, footY = p.y + 8; // feet point on the grass

    const cached = cachedSprite(p.sprite);
    if (cached) {
      const w = cached.cssW;
      const run = Math.min(1, Math.hypot(p.vx, p.vy) / 40);
      const bob = Math.sin(p.phase) * 2.2 * run; // slight vertical bob while running
      // elliptical ground shadow (stays put; only the token bobs)
      ctx.fillStyle = 'rgba(0,0,0,0.28)';
      ctx.beginPath(); ctx.ellipse(footX, footY, w * 0.34, 5, 0, 0, Math.PI * 2); ctx.fill();
      // Blit the pre-scaled canvas 1:1 on whole device pixels — no resampling
      // per frame, no half-pixel blur. The circular face tokens are
      // direction-neutral, so no mirroring; bottom of the circle sits on the
      // feet point.
      const dy = Math.round((footY + bob - SPRITE_H) * dpr);
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, Math.round((footX - w / 2) * dpr), dy);
      ctx.drawImage(cached.canvas, 0, 0);
      ctx.restore();
      // number badge tucked at the token's lower-right so it never covers the face
      const bx = footX + w * 0.36;
      const by = footY - 8;
      ctx.fillStyle = t.body;
      ctx.strokeStyle = t.trim;
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(bx, by, 8.5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = t.num;
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(p.number), bx, by + 0.5);
      return;
    }

    // Fallback while the sprite is still loading (or missing): the classic
    // colored dot from v1, so the match never breaks.
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.beginPath(); ctx.ellipse(p.x, p.y + 6, 7, 3, 0, 0, Math.PI * 2); ctx.fill();
    const legSwing = Math.sin(p.phase) * 4 * Math.min(1, Math.hypot(p.vx, p.vy) / 40);
    ctx.fillStyle = t.trim;
    ctx.beginPath(); ctx.arc(p.x - 3, p.y + 5 + legSwing, 2.2, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(p.x + 3, p.y + 5 - legSwing, 2.2, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = t.body;
    ctx.strokeStyle = t.trim;
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(p.x, p.y, 7, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = t.num;
    ctx.font = 'bold 7px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(String(p.number), p.x, p.y);
  }

  // A classic white ball with black pentagon patches that rolls with travel.
  function drawBall() {
    // contact shadow — a touch stronger so the ball sits ON the grass
    ctx.fillStyle = 'rgba(0,0,0,0.38)';
    ctx.beginPath(); ctx.ellipse(ball.x, ball.y + BALL_R + 1.5, BALL_R, 3, 0, 0, Math.PI * 2); ctx.fill();

    ctx.save();
    ctx.translate(ball.x, ball.y);
    // white sphere
    ctx.beginPath(); ctx.arc(0, 0, BALL_R, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(0,0,0,0.55)'; ctx.stroke();
    // pentagon pattern, clipped to the sphere and rotated by accumulated roll
    ctx.clip();
    ctx.rotate(ball.rot + ball.spin * 0.25);
    ctx.fillStyle = '#1b1b1b';
    pentagon(0, 0, 3.1);
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2 + Math.PI / 5;
      // partial patches around the rim — the clip crops them into crescents
      pentagon(Math.cos(a) * (BALL_R + 0.6), Math.sin(a) * (BALL_R + 0.6), 2.8);
    }
    ctx.restore();
  }

  function pentagon(cx, cy, r) {
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = -Math.PI / 2 + (i / 5) * Math.PI * 2;
      const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r;
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  }

  function drawHud() {
    // Broadcast-style scoreboard, pinned top-left like a TV graphic:
    // [BAR][2 - 1][RMA][ 12:34 ] — team blocks in club colors, running clock.
    const sbX = 10, sbY = 18, sbH = 20;
    const blockW = 34, scoreW = 46, clockW = 46;
    const sbW = blockW * 2 + scoreW + clockW;
    ctx.save();
    roundRect(sbX, sbY, sbW, sbH, 5);
    ctx.clip();
    ctx.fillStyle = TEAMS[0].body;                       // BAR block
    ctx.fillRect(sbX, sbY, blockW, sbH);
    ctx.fillStyle = 'rgba(12,18,32,0.92)';               // score panel
    ctx.fillRect(sbX + blockW, sbY, scoreW, sbH);
    ctx.fillStyle = '#ffffff';                           // RMA block
    ctx.fillRect(sbX + blockW + scoreW, sbY, blockW, sbH);
    ctx.fillStyle = 'rgba(5,10,20,0.92)';                // clock panel
    ctx.fillRect(sbX + blockW * 2 + scoreW, sbY, clockW, sbH);
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const midY = sbY + sbH / 2 + 0.5;
    ctx.fillStyle = '#ffffff';
    ctx.fillText('BAR', sbX + blockW / 2, midY);
    ctx.fillText(`${score[0]} - ${score[1]}`, sbX + blockW + scoreW / 2, midY);
    ctx.fillStyle = '#1a2a4a';
    ctx.fillText('RMA', sbX + blockW + scoreW + blockW / 2, midY);
    const mm = String(Math.floor(matchClock / 60)).padStart(2, '0');
    const ss = String(Math.floor(matchClock % 60)).padStart(2, '0');
    ctx.fillStyle = '#ffd43b';
    ctx.fillText(`${mm}:${ss}`, sbX + blockW * 2 + scoreW + clockW / 2, midY);
    ctx.restore();

    // commentary line under the scoreboard, left-aligned
    if (commentaryTtl > 0 && commentary) {
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(0,0,0,0.55)';
      ctx.strokeText(commentary, sbX + 2, sbY + sbH + 11);
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.fillText(commentary, sbX + 2, sbY + sbH + 11);
    }

    if (goalFlash > 0) {
      const pulse = 1 + Math.sin(goalFlash * 12) * 0.08;
      ctx.save();
      ctx.translate(W / 2, MID_Y);
      ctx.scale(pulse, pulse);
      ctx.font = 'bold 34px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 5;
      ctx.strokeStyle = 'rgba(0,0,0,0.55)';
      ctx.fillStyle = goalScorer >= 0 ? TEAMS[goalScorer].body : '#fff';
      ctx.strokeText('GOAL!', 0, 0);
      ctx.fillText('GOAL!', 0, 0);
      ctx.restore();
    }
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  // ---------- main loop ----------
  function stepSim(dt) {
    goalFlash = Math.max(0, goalFlash - dt);
    commentaryTtl = Math.max(0, commentaryTtl - dt);

    if (kickoffFreeze > 0) {
      kickoffFreeze -= dt;
    } else {
      matchClock += dt; // broadcast clock only runs while play is live
      updatePlayers(dt);
      if (ball) updateBall(dt);
    }
  }

  function frame(t) {
    if (!running) return;
    // Timers get throttled in background tabs, so a single tick may cover a
    // long stretch of wall time. Advance the simulation in fixed sub-steps so
    // the match keeps real-time pace without physics blowing up.
    let elapsed = (t - lastT) / 1000 || 0.016;
    lastT = t;
    elapsed = Math.min(elapsed, 2);
    const steps = Math.max(1, Math.min(120, Math.round(elapsed / 0.016)));
    const dt = elapsed / steps;
    for (let i = 0; i < steps; i++) stepSim(Math.min(dt, 0.05));

    ctx.clearRect(0, 0, W, H);
    drawPitch();
    // painter's order: players higher up the pitch are drawn first so the
    // ones nearer the bottom edge overlap them naturally
    players.slice().sort((a, b) => a.y - b.y).forEach(drawPlayer);
    if (ball) drawBall();
    drawHud();

    // lightweight state probe (isolated world in the real extension; handy in demo)
    window.__miniFootballDebug = {
      frames: (window.__miniFootballDebug ? window.__miniFootballDebug.frames : 0) + 1,
      ball: ball && { x: Math.round(ball.x), y: Math.round(ball.y) },
      score: score.slice(), kickoffFreeze, running
    };

    scheduleNext();
  }

  // rAF is suspended in hidden/background tabs; fall back to a timer there
  // so the match keeps playing and the pitch is painted when you come back.
  function scheduleNext() {
    if (!running) return;
    if (document.hidden) {
      raf = 0;
      timer = setTimeout(() => frame(performance.now()), 66);
    } else {
      raf = requestAnimationFrame(frame);
    }
  }

  document.addEventListener('visibilitychange', () => {
    if (!running) return;
    clearTimeout(timer);
    if (raf) cancelAnimationFrame(raf);
    lastT = performance.now();
    scheduleNext();
  });

  // ---------- lifecycle ----------
  function start() {
    if (running) return;
    if (!host) buildDom();
    loadSprites();
    host.style.display = 'block';
    resize();
    score = [0, 0];
    matchClock = 0;
    makePlayers();
    resetKickoff();
    say('Kick-off — it’s El Clásico!', 2);
    running = true;
    lastT = performance.now();
    frame(lastT); // paint immediately, then keep scheduling itself
  }

  function stop() {
    running = false;
    if (raf) cancelAnimationFrame(raf);
    clearTimeout(timer);
    if (host) host.style.display = 'none';
  }

  // ---------- extension wiring ----------
  function applyEnabled(enabled) { enabled ? start() : stop(); }

  try {
    chrome.storage.local.get({ footballEnabled: true }, res => {
      applyEnabled(!!(res && res.footballEnabled));
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.footballEnabled) {
        applyEnabled(!!changes.footballEnabled.newValue);
      }
    });
  } catch (e) {
    // Not running as an extension (e.g. the demo page) — start immediately.
    start();
  }
})();
