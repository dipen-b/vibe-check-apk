// Toggles the match on/off globally. Content scripts watch chrome.storage,
// so every open tab reacts immediately when the flag flips.

async function setBadge(enabled) {
  await chrome.action.setBadgeText({ text: enabled ? 'ON' : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#1e8f4e' });
}

// Tabs that were already open before the extension was installed don't have
// the content script yet — inject it on demand so no refresh is ever needed.
// content.js guards against double injection, so this is safe alongside the
// declared content script.
async function injectIntoOpenTabs() {
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*', 'file://*/*'] });
  await Promise.allSettled(tabs.map(t =>
    chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] })
  ));
}

chrome.action.onClicked.addListener(async () => {
  const { footballEnabled } = await chrome.storage.local.get({ footballEnabled: true });
  const next = !footballEnabled;
  if (next) await injectIntoOpenTabs(); // inject first so every tab hears the flag flip
  await chrome.storage.local.set({ footballEnabled: next });
  await setBadge(next);
});

async function restoreBadge() {
  const { footballEnabled } = await chrome.storage.local.get({ footballEnabled: true });
  await setBadge(footballEnabled);
}

chrome.runtime.onStartup.addListener(restoreBadge);

// The match is ON by default: on install, persist the flag if it was never
// set, light the badge, and inject the game into every tab that's already
// open so El Clásico kicks off everywhere with zero reloads.
chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get('footballEnabled');
  if (stored.footballEnabled === undefined) {
    await chrome.storage.local.set({ footballEnabled: true });
  }
  await restoreBadge();
  const { footballEnabled } = await chrome.storage.local.get({ footballEnabled: true });
  if (footballEnabled) await injectIntoOpenTabs();
});
