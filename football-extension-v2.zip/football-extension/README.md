# Mini Football — El Clásico Edition (Chrome Extension)

A Chrome extension that plays a live, self-running **Barça vs Madrid** match
on a real-looking grass pitch pinned to the bottom of every tab. Ten AI
players (5 a side, rendered as comic-style portraits of Lewandowski, Pedri,
Raphinha, Messi, Zidane, Valverde, Ronaldo, Benzema and more) chase, pass,
dribble, shoot and score entirely on their own — every match plays out
differently, with name-checked commentary ("Messi shoots!", "GOAL! Benzema
scores for MADRID").

## Features

- **Dynamic AI gameplay** — each team's nearest player hunts the ball while
  teammates hold a shifting formation; players decide per touch whether to
  shoot (near goal), pass to a better-placed teammate, or dribble on.
- **Real match flow** — goals credited to the scorer, animated `GOAL!`
  banner, live `BARÇA n : n MADRID` scoreboard, kickoff resets after every
  goal.
- **Real pitch** — opaque striped grass with full markings (centre circle,
  penalty and 6-yard boxes, spots, corner arcs) and proper goal frames with
  nets, clearly visible on light and dark pages alike.
- **On by default** — the match kicks off on every tab the moment the
  extension installs, no reloads needed. Click the toolbar icon to stop it
  everywhere (badge clears) and again to restart. A small `×` hides it per
  tab.
- **Unobtrusive** — the pitch is click-through (`pointer-events: none`), so
  the page underneath stays fully usable. The match keeps playing in
  background tabs.

## Install (Developer mode)

1. Open Chrome and go to `chrome://extensions`.
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked** and select this `football-extension` folder.
4. That's it — the match is ON by default and starts immediately at the
   bottom of all open tabs (the badge shows **ON**). Click the toolbar icon
   to stop everywhere; click again to kick off.

## Try it without installing

Open `demo.html` in any browser — it loads the same game code with the
extension APIs stubbed out, so the match starts immediately.

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | Manifest V3 definition (action button, storage, content script, web-accessible sprites) |
| `background.js` | Service worker — flips the global on/off flag, badge, install-time injection |
| `content.js` | The whole game: pitch rendering, physics, player AI, sprites, HUD |
| `players/` | Transparent PNG player portraits (loaded via `chrome.runtime.getURL`) |
| `newtab.html` / `newtab.js` | New-tab override page (clock + the match) |
| `demo.html` | Standalone preview page (no install needed) |
| `icons/` | Toolbar/store icons |

## Credits

Player sprites are comic-style portraits loaded at runtime from the
`players/` folder (`players/*.png`, exposed via `web_accessible_resources`).
Until an image finishes loading, that player is drawn as a simple colored
dot so the match never breaks.
