// ── Sippy · Water Reminder — background service worker (MV3) ────────────────
// Owns scheduling (chrome.alarms), decides when a reminder should fire, and
// asks the active tab's content script to show the animated mascot. Falls back
// to a system notification when no page can host the overlay.

const DEFAULT_SETTINGS = {
  enabled: true,
  intervalMin: 60,      // remind every N minutes
  snoozeMin: 10,        // snooze length
  goalGlasses: 8,       // daily goal
  glassMl: 250,         // ml per glass (for display)
  activeStart: "09:00", // don't nag before this
  activeEnd: "22:00",   // …or after this
  sound: true,
  customTimes: [],      // extra fixed daily reminders, e.g. ["14:00"]
};

const DEFAULT_STATE = {
  day: "",              // YYYY-MM-DD the counters belong to
  glasses: 0,
  lastDrinkTs: 0,
  nextDueTs: 0,         // when the next interval reminder is due
  snoozeUntilTs: 0,
  firedCustom: [],      // custom times already fired today ["14:00"]
  history: {},          // { "YYYY-MM-DD": glasses }
};

const TICK_ALARM = "sippy-tick";

// ── small helpers ───────────────────────────────────────────────────────────
function todayKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function hhmm(d = new Date()) {
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
function minutesOfDay(str) {
  const [h, m] = str.split(":").map(Number);
  return h * 60 + m;
}
function withinActiveHours(s, d = new Date()) {
  const now = d.getHours() * 60 + d.getMinutes();
  const start = minutesOfDay(s.activeStart);
  const end = minutesOfDay(s.activeEnd);
  if (start <= end) return now >= start && now <= end;
  return now >= start || now <= end; // overnight window
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}
async function getState() {
  const { state } = await chrome.storage.local.get("state");
  return { ...DEFAULT_STATE, ...(state || {}) };
}
async function setState(patch) {
  const state = await getState();
  const next = { ...state, ...patch };
  await chrome.storage.local.set({ state: next });
  return next;
}

// Roll counters to a new day, archiving yesterday into history.
async function rollDayIfNeeded() {
  const state = await getState();
  const today = todayKey();
  if (state.day === today) return state;
  const history = { ...state.history };
  if (state.day) history[state.day] = state.glasses;
  // keep last 30 days
  const keys = Object.keys(history).sort();
  while (keys.length > 30) delete history[keys.shift()];
  return setState({ day: today, glasses: 0, firedCustom: [], history });
}

// ── scheduling core ─────────────────────────────────────────────────────────
async function computeNextDue(fromTs = Date.now()) {
  const s = await getSettings();
  return setState({ nextDueTs: fromTs + s.intervalMin * 60000 });
}

async function ensureAlarm() {
  const existing = await chrome.alarms.get(TICK_ALARM);
  if (!existing) {
    chrome.alarms.create(TICK_ALARM, { periodInMinutes: 1, delayInMinutes: 0.1 });
  }
}

async function tick() {
  await rollDayIfNeeded();
  const s = await getSettings();
  if (!s.enabled) return;
  const now = Date.now();
  const d = new Date(now);

  // honor snooze
  const state = await getState();
  if (state.snoozeUntilTs && now < state.snoozeUntilTs) return;

  if (!withinActiveHours(s, d)) return;

  // 1) fixed custom times
  const cur = hhmm(d);
  if (s.customTimes.includes(cur) && !state.firedCustom.includes(cur)) {
    await setState({ firedCustom: [...state.firedCustom, cur] });
    return fireReminder("custom");
  }

  // 2) interval reminders
  if (!state.nextDueTs) {
    await computeNextDue(now);
    return;
  }
  if (now >= state.nextDueTs) {
    return fireReminder("interval");
  }
}

const MESSAGES = [
  "Time for a water break! 💧",
  "Hey! Your body called — it wants water 🥤",
  "Hydration check! Take a sip 💙",
  "A glass of water keeps the tired away 💦",
  "Psst… drink some water and glow ✨",
  "Little sip, big difference. Drink up! 🌊",
];

async function fireReminder(reason) {
  const s = await getSettings();
  const state = await getState();
  const remaining = Math.max(0, s.goalGlasses - state.glasses);
  const payload = {
    title: "Sippy",
    message: MESSAGES[Math.floor(Math.random() * MESSAGES.length)],
    glasses: state.glasses,
    goal: s.goalGlasses,
    remaining,
    snoozeMin: s.snoozeMin,
    sound: s.sound,
    reason,
  };
  // push interval clock forward so we don't re-fire while the popup is open
  await computeNextDue(Date.now());

  const shown = await showInActiveTab(payload);
  if (!shown) showNotification(payload);
}

// Try to render the mascot overlay in the focused tab; inject the content
// script on the fly if it isn't there yet (e.g. tab opened before install).
async function showInActiveTab(payload) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab || !tab.id || !tab.url) return false;
    if (!/^https?:|^file:/.test(tab.url)) return false; // can't inject on chrome://, store, etc.

    try {
      await chrome.tabs.sendMessage(tab.id, { type: "SHOW_REMINDER", payload });
      return true;
    } catch (_) {
      // content script not present — inject then retry
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content/content.css"] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content/content.js"] });
      await chrome.tabs.sendMessage(tab.id, { type: "SHOW_REMINDER", payload });
      return true;
    }
  } catch (e) {
    return false;
  }
}

const NOTIF_ID = "sippy-reminder";
function showNotification(payload) {
  chrome.notifications.create(NOTIF_ID, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("icons/icon128.png"),
    title: payload.title + " 💧",
    message: `${payload.message}\n${payload.glasses}/${payload.goal} glasses today.`,
    priority: 2,
    buttons: [{ title: "💧 I drank a glass" }, { title: `😴 Snooze ${payload.snoozeMin}m` }],
    requireInteraction: true,
  });
}

// ── user actions ────────────────────────────────────────────────────────────
async function logDrink() {
  await rollDayIfNeeded();
  const state = await getState();
  const now = Date.now();
  await setState({
    glasses: state.glasses + 1,
    lastDrinkTs: now,
    snoozeUntilTs: 0,
  });
  await computeNextDue(now); // drinking resets the interval timer
  broadcastState();
}

async function snooze(minOverride) {
  const s = await getSettings();
  const min = minOverride || s.snoozeMin;
  const until = Date.now() + min * 60000;
  await setState({ snoozeUntilTs: until, nextDueTs: until });
  broadcastState();
}

// let the popup refresh live
function broadcastState() {
  chrome.runtime.sendMessage({ type: "STATE_CHANGED" }).catch(() => {});
}

// ── event wiring ────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  const { settings } = await chrome.storage.local.get("settings");
  if (!settings) await chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
  await rollDayIfNeeded();
  await computeNextDue(Date.now());
  await ensureAlarm();
});

chrome.runtime.onStartup.addListener(async () => {
  await rollDayIfNeeded();
  await ensureAlarm();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === TICK_ALARM) tick();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case "DRINK":
        await logDrink();
        sendResponse({ ok: true });
        break;
      case "SNOOZE":
        await snooze(msg.minutes);
        sendResponse({ ok: true });
        break;
      case "DISMISS":
        sendResponse({ ok: true });
        break;
      case "TEST_REMINDER":
        await fireReminder("test");
        sendResponse({ ok: true });
        break;
      case "SETTINGS_UPDATED":
        // interval may have changed — recompute next due from now
        await computeNextDue(Date.now());
        await ensureAlarm();
        sendResponse({ ok: true });
        break;
      case "GET_DATA": {
        const [s, st] = [await getSettings(), await getState()];
        sendResponse({ settings: s, state: st });
        break;
      }
      default:
        sendResponse({ ok: false });
    }
  })();
  return true; // async
});

// notification buttons + click
chrome.notifications.onButtonClicked.addListener(async (id, idx) => {
  if (id !== NOTIF_ID) return;
  if (idx === 0) await logDrink();
  else await snooze();
  chrome.notifications.clear(id);
});
chrome.notifications.onClicked.addListener((id) => {
  if (id === NOTIF_ID) chrome.notifications.clear(id);
});

// make sure the heartbeat exists whenever the worker wakes
ensureAlarm();
