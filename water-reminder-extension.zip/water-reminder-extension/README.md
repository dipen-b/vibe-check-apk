# 💧 Sippy — Drink Water Reminder (Chrome Extension)

A friendly animated companion who pops in from the **bottom-right** of your screen
to remind you to drink water. She floats **transparently** on the page (no black
box), and you can **Drink water** or **Snooze** right there. A full dashboard lets
you set the interval, custom times, daily goal, active hours and more.

Built from the reminder animation in `video_1783492616278.mp4` — the black
background was removed with connectivity-based keying (her dark hair is preserved),
and the always-present portion of the clip was turned into a transparent animated
WebP.

---

## Features

- **Animated transparent mascot** — she walks in, drinks, and winks, floating on
  top of whatever page you're viewing (bottom-right, slides in from the right).
- **Snooze** — postpone the reminder by your chosen number of minutes.
- **Drink water** — one click logs a glass, updates your progress, and resets the
  timer. (Clicking the mascot herself also counts!)
- **Custom reminder times** — add fixed daily nudges (e.g. `1:30 PM`).
- **Adjustable interval** — every 15 min → 3 hours.
- **Daily goal + glass size** — tracks glasses and total ml, with a progress ring.
- **Active hours** — no reminders outside your chosen window (e.g. 9:00–22:00).
- **This-week chart** — see your last 7 days of hydration.
- **Chime sound** — optional gentle bell.
- **Fallback notification** — on pages where an overlay can't be shown
  (`chrome://`, the Web Store, etc.) a system notification with the same buttons
  is used instead.
- Light **and** dark mode.

---

## Install (Load Unpacked)

1. Open Chrome and go to `chrome://extensions`.
2. Turn on **Developer mode** (top-right).
3. Click **Load unpacked**.
4. Select this folder: **`water-reminder-extension`**.
5. Pin the 💧 icon from the puzzle-piece menu for quick access.

> The reminder overlay shows on normal `http(s)` / `file` pages. On restricted
> pages (`chrome://`, Chrome Web Store) Chrome blocks all extensions from drawing,
> so Sippy falls back to a desktop notification automatically.

---

## Usage

Click the 💧 toolbar icon to open the dashboard:

- **Progress ring** — today's glasses vs. goal. Hit **＋ I drank a glass** or **－** to undo.
- **▶ Preview reminder** — fire a reminder right now to see how it looks.
- **Reminder settings** — interval, snooze length, daily goal, glass size, active hours, chime.
- **Custom reminder times** — type a time and click **Add**; remove with the ✕ chip.
- The master toggle (top-right) turns all reminders on/off.

When a reminder fires, the mascot slides in bottom-right with a speech bubble:
**💧 Drink water** logs a glass and dismisses her; **😴 Snooze** hides her for the
snooze duration; **✕** just dismisses. If ignored she leaves after 45 seconds.

---

## How it works

| File | Role |
|------|------|
| `manifest.json` | MV3 manifest, permissions, content-script + web-accessible assets |
| `background.js` | Service worker: `chrome.alarms` heartbeat (1 min), decides when to fire, messages the active tab, notification fallback, stores settings/log in `chrome.storage.local` |
| `content/content.js` | Injects the mascot overlay into the page via a **Shadow DOM** (isolated from page CSS); Drink/Snooze/Dismiss buttons |
| `content/content.css` | Keeps the host element out of page flow |
| `popup/*` | The dashboard + settings UI |
| `assets/mascot.webp` | Transparent animated mascot (124 frames, ~15 fps, loops) |
| `assets/poster.png` | Still frame (used in the popup header) |
| `assets/chime.wav` | Reminder chime |
| `icons/*` | Toolbar / store icons |

### Regenerating the mascot animation

If you want to re-process the source video (e.g. change the trim or size), the
pipeline is: extract frames → connectivity flood-fill key the black background
(preserving dark hair) → remove small speckles → restore a 2px outline → trim to
the frames where she's present → encode a looping transparent WebP with Pillow.
No `ffmpeg` required — frame extraction uses macOS AVFoundation and encoding uses
Pillow.

---

## Notes / limits

- Chrome alarms have a **1-minute minimum**, so reminders fire on the minute.
- The mascot overlay only appears in the **currently focused tab** when a reminder
  fires (so you're not spammed across every tab).
- All data is stored **locally** (`chrome.storage.local`); nothing leaves your machine.
