// ── Sippy · popup (dashboard + settings) ────────────────────────────────────
const $ = (id) => document.getElementById(id);
const CIRC = 2 * Math.PI * 52; // ring circumference

let settings = null;
let state = null;

function send(msg) {
  return new Promise((res) => chrome.runtime.sendMessage(msg, (r) => res(r)));
}

async function load() {
  const data = await send({ type: "GET_DATA" });
  settings = data.settings;
  state = data.state;
  render();
}

// ── save helpers (debounced writes to storage) ──────────────────────────────
let saveTimer = null;
async function saveSettings(patch) {
  settings = { ...settings, ...patch };
  const { settings: cur } = await chrome.storage.local.get("settings");
  await chrome.storage.local.set({ settings: { ...cur, ...patch } });
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => send({ type: "SETTINGS_UPDATED" }), 150);
}

// ── rendering ───────────────────────────────────────────────────────────────
function render() {
  // enable
  $("enabled").checked = settings.enabled;

  // progress ring
  const glasses = state.glasses || 0;
  const goal = settings.goalGlasses;
  const pct = Math.min(1, goal ? glasses / goal : 0);
  $("ringFg").style.strokeDashoffset = String(CIRC * (1 - pct));
  $("glassCount").textContent = glasses;
  $("goalLbl").textContent = goal;
  $("mlLbl").textContent = `${glasses * settings.glassMl} ml`;

  const remaining = Math.max(0, goal - glasses);
  $("progMsg").textContent =
    remaining === 0
      ? "Goal smashed! You're a hydration hero 🎉"
      : glasses === 0
      ? "Let's get sipping! 💧"
      : `${remaining} glass${remaining > 1 ? "es" : ""} to go — keep it up! 💪`;

  // week strip
  renderWeek();

  // settings controls (selects fall back to "Custom…" + minutes input)
  syncCustomSelect("interval", "intervalBox", "intervalCustom", settings.intervalMin);
  syncCustomSelect("snooze", "snoozeBox", "snoozeCustom", settings.snoozeMin);
  $("goalVal").textContent = goal;
  $("glassMl").value = String(settings.glassMl);
  $("activeStart").value = settings.activeStart;
  $("activeEnd").value = settings.activeEnd;
  $("sound").checked = settings.sound;

  renderCustomTimes();
}

function renderWeek() {
  const bars = $("weekBars");
  bars.innerHTML = "";
  const goal = settings.goalGlasses || 8;
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const today = new Date();
  let sum = 0, cnt = 0;
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const isToday = i === 0;
    const val = isToday ? state.glasses || 0 : state.history?.[key] || 0;
    if (val > 0) { sum += val; cnt++; }
    const h = Math.max(3, Math.min(1, val / goal) * 44);
    const wb = document.createElement("div");
    wb.className = "wb" + (isToday ? " today" : "");
    wb.innerHTML = `<div class="wb-fill" style="height:${h}px" title="${val} glasses"></div>
      <span class="wb-lbl">${days[d.getDay()]}</span>`;
    bars.appendChild(wb);
  }
  $("weekAvg").textContent = cnt ? `avg ${(sum / cnt).toFixed(1)}/day` : "";
}

function renderCustomTimes() {
  const ul = $("customList");
  ul.innerHTML = "";
  const times = [...(settings.customTimes || [])].sort();
  for (const t of times) {
    const li = document.createElement("li");
    li.className = "chip";
    li.innerHTML = `<span>${fmt12(t)}</span><button title="Remove">✕</button>`;
    li.querySelector("button").addEventListener("click", async () => {
      await saveSettings({ customTimes: settings.customTimes.filter((x) => x !== t) });
      renderCustomTimes();
    });
    ul.appendChild(li);
  }
}

// Reflect a minutes value into a select that has preset options + "custom".
function syncCustomSelect(selId, boxId, inputId, minutes) {
  const sel = $(selId);
  const isPreset = [...sel.options].some((o) => o.value === String(minutes));
  sel.value = isPreset ? String(minutes) : "custom";
  $(boxId).classList.toggle("hidden", isPreset);
  if (!isPreset) $(inputId).value = minutes;
}

function clampMin(v, min, max, fallback) {
  const n = Math.round(Number(v));
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

function fmt12(t) {
  const [h, m] = t.split(":").map(Number);
  const ap = h >= 12 ? "PM" : "AM";
  const h12 = ((h + 11) % 12) + 1;
  return `${h12}:${String(m).padStart(2, "0")} ${ap}`;
}

// ── events ──────────────────────────────────────────────────────────────────
$("enabled").addEventListener("change", (e) => saveSettings({ enabled: e.target.checked }));

$("drinkBtn").addEventListener("click", async () => {
  await send({ type: "DRINK" });
  await load();
  pop($("glassCount"));
});
$("undoBtn").addEventListener("click", async () => {
  const { state: st } = await chrome.storage.local.get("state");
  const g = Math.max(0, (st?.glasses || 0) - 1);
  await chrome.storage.local.set({ state: { ...st, glasses: g } });
  await load();
});
$("testBtn").addEventListener("click", async () => {
  await send({ type: "TEST_REMINDER" });
  window.close(); // so the reminder is visible on the page
});

$("interval").addEventListener("change", (e) => {
  if (e.target.value === "custom") {
    $("intervalBox").classList.remove("hidden");
    $("intervalCustom").value = settings.intervalMin;
    $("intervalCustom").focus();
    $("intervalCustom").select();
  } else {
    $("intervalBox").classList.add("hidden");
    saveSettings({ intervalMin: +e.target.value });
  }
});
$("intervalCustom").addEventListener("change", (e) => {
  const v = clampMin(e.target.value, 1, 720, settings.intervalMin);
  e.target.value = v;
  saveSettings({ intervalMin: v });
});

$("snooze").addEventListener("change", (e) => {
  if (e.target.value === "custom") {
    $("snoozeBox").classList.remove("hidden");
    $("snoozeCustom").value = settings.snoozeMin;
    $("snoozeCustom").focus();
    $("snoozeCustom").select();
  } else {
    $("snoozeBox").classList.add("hidden");
    saveSettings({ snoozeMin: +e.target.value });
  }
});
$("snoozeCustom").addEventListener("change", (e) => {
  const v = clampMin(e.target.value, 1, 240, settings.snoozeMin);
  e.target.value = v;
  saveSettings({ snoozeMin: v });
});
$("glassMl").addEventListener("change", (e) => { saveSettings({ glassMl: +e.target.value }); render(); });
$("activeStart").addEventListener("change", (e) => saveSettings({ activeStart: e.target.value }));
$("activeEnd").addEventListener("change", (e) => saveSettings({ activeEnd: e.target.value }));
$("sound").addEventListener("change", (e) => saveSettings({ sound: e.target.checked }));

$("goalPlus").addEventListener("click", () => { const v = Math.min(20, settings.goalGlasses + 1); saveSettings({ goalGlasses: v }); render(); });
$("goalMinus").addEventListener("click", () => { const v = Math.max(1, settings.goalGlasses - 1); saveSettings({ goalGlasses: v }); render(); });

$("addTime").addEventListener("click", async () => {
  const t = $("customTime").value;
  if (!t) return;
  if (settings.customTimes.includes(t)) return;
  await saveSettings({ customTimes: [...settings.customTimes, t] });
  $("customTime").value = "";
  renderCustomTimes();
});

$("resetBtn").addEventListener("click", async () => {
  const { state: st } = await chrome.storage.local.get("state");
  await chrome.storage.local.set({ state: { ...st, glasses: 0 } });
  await load();
});

// live update if background changes state (e.g. drink from a reminder)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "STATE_CHANGED") load();
});

function pop(el) {
  el.animate(
    [{ transform: "scale(1)" }, { transform: "scale(1.25)" }, { transform: "scale(1)" }],
    { duration: 300, easing: "ease-out" }
  );
}

load();
