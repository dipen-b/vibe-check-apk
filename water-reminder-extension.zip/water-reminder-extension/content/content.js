// ── Sippy · content script ──────────────────────────────────────────────────
// Renders the transparent animated mascot in the bottom-right corner of the
// page when the background worker says a reminder is due. Uses a Shadow DOM so
// the host page's CSS can never interfere.

(() => {
  if (window.__sippyInjected) return; // guard against double-injection
  window.__sippyInjected = true;

  const MASCOT_URL = chrome.runtime.getURL("assets/mascot.webp");
  const CHIME_URL = chrome.runtime.getURL("assets/chime.wav");

  let host = null;
  let hideTimer = null;

  function removeWidget() {
    if (hideTimer) clearTimeout(hideTimer);
    if (host) {
      const card = host.shadowRoot.querySelector(".sippy-wrap");
      if (card) card.classList.add("sippy-leaving");
      const h = host;
      host = null;
      setTimeout(() => h.remove(), 480);
    }
  }

  function send(type, extra = {}) {
    try {
      chrome.runtime.sendMessage({ type, ...extra });
    } catch (_) {}
  }

  function showWidget(payload) {
    removeWidget(); // never stack two

    host = document.createElement("div");
    host.id = "sippy-host";
    // keep the host itself out of the page flow / above everything
    host.style.cssText =
      "all:initial;position:fixed;z-index:2147483647;right:0;bottom:0;width:0;height:0;";
    const root = host.attachShadow({ mode: "open" });

    root.innerHTML = `
      <style>
        :host { all: initial; }
        .sippy-wrap{
          position: fixed; right: 22px; bottom: 22px;
          display: flex; flex-direction: column; align-items: center; gap: 10px;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          transform: translateX(140%); opacity: 0;
          animation: sippyIn .6s cubic-bezier(.18,.9,.24,1.15) forwards;
          pointer-events: none;
        }
        .sippy-wrap.sippy-leaving{ animation: sippyOut .45s ease-in forwards; }
        @keyframes sippyIn { to { transform: translateX(0); opacity: 1; } }
        @keyframes sippyOut { to { transform: translateX(140%); opacity: 0; } }

        /* transparent mascot — no box, she floats on the page (big!) */
        .sippy-mascot{
          width: 360px; height: auto; display: block;
          filter: drop-shadow(0 14px 20px rgba(0,0,0,.28));
          pointer-events: auto; cursor: pointer;
          -webkit-user-select: none; user-select: none;
        }

        /* just the two floating buttons under her */
        .sippy-actions{ display:flex; gap:10px; pointer-events:auto; }
        .sippy-btn{
          border:none; border-radius:999px; padding:12px 20px;
          font-size:14px; font-weight:800; cursor:pointer;
          transition:transform .08s ease, filter .2s ease, background .2s ease;
        }
        .sippy-btn:active{ transform:translateY(1px); }
        .sippy-drink{
          color:#fff; background:linear-gradient(135deg,#38bdf8,#2563eb);
          box-shadow:0 8px 20px rgba(37,99,235,.42);
        }
        .sippy-drink:hover{ filter:brightness(1.06); }
        .sippy-snooze{
          color:#2563eb; background:rgba(255,255,255,.95);
          border:1px solid rgba(37,99,235,.25);
          box-shadow:0 8px 20px rgba(30,64,120,.20);
        }
        .sippy-snooze:hover{ background:#fff; }
        @media (prefers-color-scheme: dark){
          .sippy-snooze{ color:#8ab6ff; background:rgba(22,30,46,.95);
            border-color:rgba(96,165,250,.35); }
          .sippy-snooze:hover{ background:rgba(30,41,64,.98); }
        }
      </style>
      <div class="sippy-wrap" part="wrap">
        <img class="sippy-mascot" alt="Sippy" src="${MASCOT_URL}">
        <div class="sippy-actions">
          <button class="sippy-btn sippy-drink">💧 Drink water</button>
          <button class="sippy-btn sippy-snooze"></button>
        </div>
      </div>
    `;

    const $ = (s) => root.querySelector(s);
    $(".sippy-snooze").textContent = `😴 Snooze ${payload.snoozeMin}m`;

    $(".sippy-drink").addEventListener("click", () => {
      send("DRINK");
      removeWidget();
    });
    $(".sippy-snooze").addEventListener("click", () => {
      send("SNOOZE");
      removeWidget();
    });
    // clicking the mascot herself also counts as "drink"
    $(".sippy-mascot").addEventListener("click", () => {
      send("DRINK");
      removeWidget();
    });

    document.documentElement.appendChild(host);

    if (payload.sound) {
      try {
        const a = new Audio(CHIME_URL);
        a.volume = 0.5;
        a.play().catch(() => {});
      } catch (_) {}
    }

    // auto-dismiss after 45s if ignored
    hideTimer = setTimeout(removeWidget, 45000);
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "SHOW_REMINDER") {
      showWidget(msg.payload || {});
      sendResponse && sendResponse({ ok: true });
    }
    return true;
  });
})();
